 ------------------------------------------------------------------------------------------------------------

/*
�޸�ʱ�䣺2008-11-17
�޸��ˣ�  Liuxt	
�޸����ݣ��޸Ŀ��ڷ����㷨��ͬʱ֧�������Ű�
*/

IF EXISTS (SELECT name FROM sysobjects 
         WHERE name = 'PRO_QueryCurrentDay' AND type = 'P')
   DROP PROCEDURE PRO_QueryCurrentDay
GO

CREATE   PROCEDURE [dbo].[PRO_QueryCurrentDay]  ( 
	@nPersonID  int, 
	@dtQuery  DATETIME, 
	@nSquadID int,							--���ID
	@nOndutyRs int, 						--���ϰ�ʱ��Ϊ��׼,�������ϰ࿨����ǰʱ��.�Է���Ϊ��λ
	@nOndutyRe int, 						--���ϰ�ʱ��Ϊ��׼,�������ϰ࿨���Ӻ�ʱ��.�Է���Ϊ��λ
	@nOffdutyRs int, 						--���°�ʱ��Ϊ��׼,�������°࿨����ǰʱ��.�Է���Ϊ��λ
	@nOffdutyRe int,						--���°�ʱ��Ϊ��׼,�������°࿨���Ӻ�ʱ��.�Է���Ϊ��λ
	@nLateMinute int,						--�ٵ�����ʱ��
	@nLeaveMinute int, 						--��������ʱ��
	@bFirstPassDay int, 					--ǰ���쿼��
	@bLastPassDay int) 						--����쿼��
WITH ENCRYPTION  
AS

	DECLARE @dtStartTimeTSG DATETIME, 		--���ϰ�ʱ��
			@dtEndTimeTSG DATETIME,			--���°�ʱ��
			@dtNextSTimeTSG DATETIME,		--�´��ϰ��ʱ��
			@dtNextETimeTSG DATETIME;		--�´��°��ʱ��
	DECLARE @dt1 DATETIME
	DECLARE @dt2 DATETIME
	DECLARE @dtnext1 DATETIME
	DECLARE @dtnext2 DATETIME
	DECLARE @dtnextCard DATETIME
	DECLARE @dtCurrCard DATETIME
	DECLARE @TMP1 INT, @TMP2 INT, @TMP3 int;
	DECLARE @dtOndTime DATETIME, @dtOffdTime DATETIME, @nOndMinute int, @nOffdMinute int, 
			@nAbsentMode int					/*�Ƿ���ǩ����¼*/
	DECLARE @bHasOnCard int,@bHasOffCard int	/*�Ƿ����ϰ࿨  �����°࿨*/
	DECLARE @nMinTsgID int, @nMaxTsgID int, 	--������С���ʱ��κ������ʱ���
			@nTsgID int, @nTsgNextID int
	DECLARE @nSquadID3 int 
	DECLARE @dCurTimePoint DATETIME;			--��ǰ������ʱ���
	DECLARE @bHasFetch bit;
	DECLARE @nLastFetchStatues int;
	print convert( varchar, @dtQuery, 112 ) + '--' + cast( @bFirstPassDay as varchar) + ':' + cast( @bLastPassDay as varchar)
	set @bFirstPassDay = isnull(@bFirstPassDay, 0);
	set @bLastPassDay = isnull(@bLastPassDay, 0);
	/*��ȡ���а��ʱ���*/
	DECLARE cur2 CURSOR for  SELECT [STARTTIME], [ENDTIME],[TSEG_ID]  FROM [dbo].TSG_View where [SQUADID] =  @nSquadID ORDER BY [TSEG_ID]
	set @nSquadID3 = @nSquadID

	SET @dCurTimePoint = NULL;
	
	/*������С���ʱ��κ������ʱ���*/
	SELECT @nMinTsgID = Min([TSEG_ID]), @nMaxTsgID = Max([TSEG_ID])  FROM [dbo].TSG_View where [SQUADID] =  @nSquadID
	open cur2
	fetch next from cur2 into @dtStartTimeTSG , @dtEndTimeTSG, @nTsgID/*ʱ���ID*/
	set @nLastFetchStatues = @@FETCH_STATUS;

	/*��ϳ�����İ��ʱ���*/
	set @dtStartTimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtStartTimeTSG))+':'+RTRIM(DATEPART(minute,@dtStartTimeTSG))+':'+RTRIM(DATEPART(second,@dtStartTimeTSG))
	set @dtEndTimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtEndTimeTSG))+':'+RTRIM(DATEPART(minute,@dtEndTimeTSG))+':'+RTRIM(DATEPART(second,@dtEndTimeTSG))
	set @bHasFetch = 0;
	WHILE @nLastFetchStatues = 0
	BEGIN
		set @bHasOnCard = 0	/*�Ƿ����ϰ࿨*/
		set @bHasOffCard = 0	/*�Ƿ����°࿨*/
		set @nAbsentMode = 0	/*�Ƿ���ǩ����¼*/

		--�������������ϰ࿨		
		if NOT(@bFirstPassDay = 1 AND @nTsgID = @nMinTsgID)	/*���� ��ǰ���ڿ����ҵ�һ�����ʱ��Ρ��� ���������ڴ���������ٵ���������*/
		begin
			--if exists  (SELECT * FROM [dbo].[CardLog] where [nPERSONID] = @nPersonID AND 
				--[dtStartTime] >= DATEADD(minute, -@nOndutyRs, @dtStartTimeTSG) AND [dtStartTime] <= DATEADD(minute, @nOndutyRe, @dtStartTimeTSG) )

			set @dt1 = '2000-01-01'
			set @dt2 = DATEADD(minute, @nLateMinute, @dtStartTimeTSG)
			
			--��û��ǩ��������о�ȡ��ǩ������
			if exists  (SELECT * FROM [dbo].[Sign] where [PERSONID] = @nPersonID AND @dtStartTimeTSG>=[StartTime] AND @dtStartTimeTSG<=[EndTime])
			begin
				SELECT top 1 @nAbsentMode = [SIGN_TYPE] FROM [dbo].[Sign] where [PERSONID] = @nPersonID AND @dtStartTimeTSG>=[StartTime] AND @dtStartTimeTSG<=[EndTime]
			end
			else
			begin
				--�����ϰ࿨
				SELECT top 1 @dt1 = [dtStartTime] 
				FROM [CardLog] 
				where [nPERSONID] = @nPersonID AND 
					[dtStartTime] >= DATEADD(minute, -@nOndutyRs, @dtStartTimeTSG) AND --��������ǰʱ��
					[dtStartTime] <= DATEADD(minute, @nOndutyRe, @dtStartTimeTSG) AND --�����Ӻ��ʱ��
					( @dCurTimePoint IS NULL OR @dCurTimePoint < dtStartTime ) AND 
					EXISTS( SELECT * FROM attendance_reader WHERE nDoorID = CardLog.nDevice AND [index] + 1 = CardLog.nReaderIndex )
				ORDER BY [dtStartTime]
				
				
				
				if ( datepart(year,@dt1) <> 2000 )--��û��ˢ����¼
				begin
					SET @dCurTimePoint = @dt1;
					set @dtOndTime = @dt1
					if @dt1 > @dt2
					begin
						set @dt1 = @dt1  - @dtStartTimeTSG

						--����ٵ�������
						set @nOndMinute = (DATEPART(hour,@dt1) * 60 + DATEPART(minute,@dt1))*60 + DATEPART(second,@dt1)
					end
					else
					begin
						set @nOndMinute = 0
					end
					set @bHasOnCard = 1
				end
			end
		end

		--�������������°࿨		
		if NOT(@bLastPassDay = 1 AND @nTsgID = @nMaxTsgID)	/*���� �����ڿ��������һ�����ʱ��Ρ��� ���������ڴ���������ٵ���������*/
		begin
			--if exists  (SELECT * FROM [dbo].[CardLog] where [nPERSONID] = @nPersonID AND 
			--	[dtStartTime] >= DATEADD(minute, -@nOffdutyRs, @dtEndTimeTSG) AND [dtStartTime] <= DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG) )

			set @dt1 = '2000-01-01'
			set @dt2 = DATEADD(minute, -@nLeaveMinute, @dtEndTimeTSG)
			
			if exists  (SELECT * FROM [dbo].[Sign] where [PERSONID] = @nPersonID AND @dtEndTimeTSG >=[StartTime] AND @dtEndTimeTSG <=[EndTime])
			begin
				DECLARE @nAbsent1 int
				SELECT top 1 @nAbsent1 = [SIGN_TYPE] FROM [dbo].[Sign] where [PERSONID] = @nPersonID AND @dtEndTimeTSG >=[StartTime] AND @dtEndTimeTSG <=[EndTime]			

				set @nAbsentMode = @nAbsent1*10 +  @nAbsentMode;
			end
			else
			begin
				--���һ���°�ȡ����ˢ��ʱ��
				--�м���°࿨ȡ�����°�ʱ��
				IF @nTsgID = @nMaxTsgID
				BEGIN
					SELECT top 1 @dt1 = [dtStartTime] 
					FROM [dbo].[CardLog] 
					where [nPERSONID] = @nPersonID AND 
						[dtStartTime] >= DATEADD(minute, -@nOffdutyRs, @dtEndTimeTSG) AND 
						[dtStartTime] <= DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG) AND
						( @dCurTimePoint IS NULL OR @dCurTimePoint < dtStartTime ) AND 
						EXISTS( SELECT * FROM attendance_reader WHERE nDoorID = CardLog.nDevice AND [index] + 1 = CardLog.nReaderIndex )
					ORDER BY [dtStartTime] DESC
				END
				ELSE
				BEGIN
					fetch next from cur2 into @dtNextSTimeTSG , @dtNextETimeTSG, @nTsgNextID/*ʱ���ID*/
					set @nLastFetchStatues = @@FETCH_STATUS;
					set @dtNextSTimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtNextSTimeTSG))+':'+RTRIM(DATEPART(minute,@dtNextSTimeTSG))+':'+RTRIM(DATEPART(second,@dtNextSTimeTSG))
					set @dtNextETimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtNextETimeTSG))+':'+RTRIM(DATEPART(minute,@dtNextETimeTSG))+':'+RTRIM(DATEPART(second,@dtNextETimeTSG))
					set @bHasFetch = 1;
					SET @TMP1 = -99999999;
					SET @TMP2 = -99999999;
					set @dtnext2 = DATEADD(minute, @nLateMinute, @dtNextSTimeTSG);
					--ȡ���Ŵ�ʱ��
					IF DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG) > DATEADD(minute, -@nOndutyRs, @dtNextSTimeTSG)
					BEGIN
						--�°�����ϰ��ʱ�䷶Χ���ܳ��ֵ���
						DECLARE curCardLog CURSOR LOCAL FORWARD_ONLY READ_ONLY for SELECT distinct [dtStartTime] FROM [CardLog] 
						where [nPERSONID] = @nPersonID AND 
							[dtStartTime] >= DATEADD(minute, -@nOffdutyRs, @dtEndTimeTSG) AND 
							[dtStartTime] <= DATEADD(minute, @nOndutyRe, @dtNextSTimeTSG) AND 
							( @dCurTimePoint IS NULL OR @dCurTimePoint < dtStartTime ) AND 
							EXISTS( SELECT * FROM attendance_reader WHERE nDoorID = CardLog.nDevice AND [index] + 1 = CardLog.nReaderIndex )
						ORDER BY [dtStartTime];
						set @dtCurrCard = '2000-01-01'
						open curCardLog;
						fetch next from curCardLog into @dtCurrCard;
						if @dtCurrCard < DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG)
							set @dt1 = @dtCurrCard;
						while @@FETCH_STATUS = 0
						begin
							if @dtCurrCard > DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG)
								break;
							fetch next from curCardLog into @dtnextCard;
							IF @@FETCH_STATUS <> 0
							BEGIN
								break;
							END
							if @dtnextCard < DATEADD(minute, -@nOndutyRs, @dtNextSTimeTSG)
							begin
								set @dtCurrCard = @dtnextCard;
								set @dt1 = @dtCurrCard;
							end
							else
							begin
								--��������ʱ��
								set @TMP2 = DATEDIFF ( minute, @dt2, @dtCurrCard );
								set @TMP3 = DATEDIFF ( minute, @dtnextCard, @dtnext2 );
								if @TMP2 < 0
									set @TMP2 = @TMP2 * 3600;
								if @TMP3 < 0
									set @TMP3 = @TMP3 * 3600;
								else
									set @TMP3 = 0;
								if @TMP2 + @TMP3 > @TMP1
								BEGIN
									SET @TMP1 = @TMP2 + @TMP3;
									set @dt1 = @dtCurrCard;
								END
								set @dtCurrCard = @dtnextCard;
							end
						end
						close curCardLog
						DEALLOCATE curCardLog
					END
					ELSE
					BEGIN
						SELECT top 1 @dt1 = [dtStartTime] 
						FROM [dbo].[CardLog] 
						where [nPERSONID] = @nPersonID AND 
							[dtStartTime] >= DATEADD(minute, -@nOffdutyRs, @dtEndTimeTSG) AND 
							[dtStartTime] <= DATEADD(minute, @nOffdutyRe, @dtEndTimeTSG) AND 
							( @dCurTimePoint IS NULL OR @dCurTimePoint < dtStartTime ) AND 
							EXISTS( SELECT * FROM attendance_reader WHERE nDoorID = CardLog.nDevice AND [index] + 1 = CardLog.nReaderIndex )
						ORDER BY [dtStartTime] DESC
					END
				END

					--�Ƿ����°࿨
				if ( datepart(year,@dt1) <> 2000 )
				begin
					SET @dCurTimePoint = @dt1;
					set @dtOffdTime = @dt1
					if @dt1 <  @dt2
					begin
						set @dt1 = @dtEndTimeTSG  - @dt1--�������˷�����
						set @nOffdMinute = (DATEPART(hour,@dt1) * 60 + DATEPART(minute,@dt1))*60 + DATEPART(second,@dt1)
					end
					else
					begin
						set @nOffdMinute = 0
					end
					set @bHasOffCard = 1
				end
			end
		end

		if @bHasOnCard = 1	/*���ϰ࿨*/
		begin
			if @bHasOffCard = 1	/*���ϰ࿨�����°࿨������һ����¼*/
			begin
				INSERT INTO [dbo].[CardLogAnalysis]([PERSONID], [DAY], [OND_TIME], [OND_SECOND], [OFFD_TTIME], [OFFD_SECOND], [SQUADID], firstCardTime, [ABSENT_MODE]) 
					VALUES (@nPersonID, @dtQuery, @dtOndTime, @nOndMinute, @dtOffdTime, @nOffdMinute, @nSquadID3, @dtStartTimeTSG, @nAbsentMode )
			end
			else			/*���ϰ࿨�����°࿨*/
			begin
				INSERT INTO [dbo].[CardLogAnalysis]([PERSONID], [DAY], firstCardTime, [OND_TIME],[OND_SECOND],[ABSENT_MODE],[SQUADID]) VALUES (@nPersonID, @dtQuery, @dtStartTimeTSG, @dtOndTime, @nOndMinute, @nAbsentMode,@nSquadID3)
			end
		end
		else		/*���ϰ࿨*/
		begin
			if @bHasOffCard = 1	/*���ϰ࿨�����°࿨*/
			begin
				if @bFirstPassDay = 1 AND @nTsgID = @nMinTsgID	/*ǰ���ڿ������ǵ�һ�����ʱ���*/
				begin
					UPDATE CardLogAnalysis 
					set [OFFD_TTIME]=@dtOffdTime, [OFFD_SECOND]=@nOffdMinute,[ABSENT_MODE] = [ABSENT_MODE] + @nAbsentMode 
					WHERE [PERSONID] = @nPersonID AND [DAY] = DATEADD(day,-1,@dtQuery) 
						and firstCardTime = ( select max(firstCardTime) from [CardLogAnalysis] where [PERSONID] = @nPersonID AND [DAY] = DATEADD(day,-1,@dtQuery)  );
				end
				else	/*���������ϰ�ʱ��Σ��Ͳ���ȱ�ڼ�¼*/
				begin
					INSERT INTO [dbo].[CardLogAnalysis]([PERSONID], [DAY], firstCardTime,[OFFD_TTIME],[OFFD_SECOND], [ABSENT_MODE], [SQUADID]) VALUES (@nPersonID, @dtQuery, @dtStartTimeTSG, @dtOffdTime, @nOffdMinute, @nAbsentMode, @nSquadID3)
				end
			end
			else	/*���ϰ࿨�����°࿨*/
			begin
				if @bFirstPassDay = 1 AND @nTsgID = @nMinTsgID
				begin
					UPDATE CardLogAnalysis 
					set [OFFD_TTIME]=@dtOffdTime, [OFFD_SECOND]=@nOffdMinute,[ABSENT_MODE] = [ABSENT_MODE] + @nAbsentMode 
					WHERE [PERSONID] = @nPersonID AND [DAY] = DATEADD(day,-1,@dtQuery) 
						and firstCardTime = ( select max(firstCardTime) from [CardLogAnalysis] where [PERSONID] = @nPersonID AND [DAY] = DATEADD(day,-1,@dtQuery)  );
				end
				else
				begin
					INSERT INTO [dbo].[CardLogAnalysis]([PERSONID], [DAY], firstCardTime,[ABSENT_MODE], [SQUADID]) VALUES (@nPersonID, @dtQuery, @dtStartTimeTSG, @nAbsentMode, @nSquadID3 )
				end
			end
		end
		if @bHasFetch = 1
		begin
			set @dtStartTimeTSG = @dtNextSTimeTSG;
			set @dtEndTimeTSG = @dtNextETimeTSG;
			set @nTsgID = @nTsgNextID;
			set @bHasFetch = 0;
		end
		else
		begin
   			FETCH NEXT FROM cur2  into @dtStartTimeTSG , @dtEndTimeTSG, @nTsgID
   			set @nLastFetchStatues = @@FETCH_STATUS;
			/*��ϳ�����İ��ʱ���*/
			set @dtStartTimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtStartTimeTSG))+':'+RTRIM(DATEPART(minute,@dtStartTimeTSG))+':'+RTRIM(DATEPART(second,@dtStartTimeTSG))
			set @dtEndTimeTSG = RTRIM(YEAR(@dtQuery))+'-'+RTRIM(MONTH(@dtQuery))+'-'+RTRIM(DAY(@dtQuery))+' '+RTRIM(DATEPART(hour,@dtEndTimeTSG))+':'+RTRIM(DATEPART(minute,@dtEndTimeTSG))+':'+RTRIM(DATEPART(second,@dtEndTimeTSG))
		end
	END
	close cur2
	DEALLOCATE cur2
GO


----------------------------------------------------------------------------------------------------------------
IF EXISTS (SELECT name FROM sysobjects WHERE name = 'PRO_QueryCardLog' AND type = 'P')
    DROP PROCEDURE PRO_QueryCardLog
GO

create PROCEDURE [PRO_QueryCardLog] (@nPersonID [int],  @dtStartTime [DATETIME],  @dtEndTime [DATETIME] , @dwType [int])
	AS
if @nPersonID=0
	begin
		DECLARE  @nPersonID1 int
		if exists (SELECT [nID] FROM [dbo].[Personnel] t where not exists(select 1 from Container where nSubClassID = 58 and nSubObjectID = t.nID))
			begin
				DECLARE cur4 CURSOR local for (SELECT [nID] FROM [dbo].[Personnel] t where not exists(select 1 from Container where nSubClassID = 58 and nSubObjectID = t.nID))
				open cur4
				fetch next from cur4 into @nPersonID1
				WHILE @@FETCH_STATUS = 0
					begin
						if @nPersonID1>0
							begin
								exec dbo.PRO_QueryCardLog @nPersonID1,  @dtStartTime,  @dtEndTime, 0;
							end
						fetch next from cur4 into @nPersonID1
					end
				close cur4
				DEALLOCATE cur4
			end
	end
else
	begin
		if  @dwType = 1 OR @dwType = 2		/*��������£�@nPersonIDʵ������һ����Ա��ID*/
			begin 
				DECLARE  @nSubObjectID int, @nSubClassID int
				if exists (select nSubObjectID, nSubClassID from Container 
					where nContainerClassID = 59 and nContainerID = @nPersonID)
				begin
					DECLARE cur5 CURSOR LOCAL for (select nSubObjectID, nSubClassID from Container 
						where nContainerClassID = 59 and nContainerID = @nPersonID  );
					open cur5
					fetch next from cur5 into @nSubObjectID, @nSubClassID
					WHILE @@FETCH_STATUS = 0
					begin
						if @nSubClassID=58 AND @nSubObjectID>0
						begin
							exec dbo.PRO_QueryCardLog @nSubObjectID,  @dtStartTime,  @dtEndTime, 0
						end
						else
						begin
							if @nSubClassID=59 AND @nSubObjectID>0
								exec dbo.PRO_QueryCardLog @nSubObjectID,  @dtStartTime,  @dtEndTime, @dwType;
						end
						fetch next from cur5 into @nSubObjectID, @nSubClassID
					end
					close cur5
					DEALLOCATE cur5
				end
			end 
		else
			begin
				DECLARE  @nSquadID int
				DECLARE  @dtStartTimeSplan DATETIME, @dtEndTimeSplan DATETIME
				
				DECLARE  @nSquadIDNext int
				DECLARE  @dtStartTimeSplanNext DATETIME, @dtEndTimeSplanNext DATETIME
				DECLARE  @bContinue 	int
				
				DECLARE  @dtStartTimeTSG DATETIME, @dtEndimeTSG DATETIME
				DECLARE  @nOndutyRs int, @nOnDutyRe int, @nOffdutyRs int, @nOffDutyRe int, @nLateMinute int, @nLeaveMinute int
				DECLARE  @dt1 DATETIME
				DECLARE  @dt2 DATETIME
				DECLARE  @dt3 DATETIME
				
				--set @dtStartTime = CONVERT(char(10), @dtStartTime, 120)
				--set @dtEndTime = CONVERT(char(10), @dtEndTime, 120)
				set @bContinue	=	0;

				--ɾ����ǰ�ķ������
				DELETE FROM CardLogAnalysis WHERE [PERSONID]=@nPersonID AND [DAY]>=@dtStartTime AND [DAY]<=@dtEndTime

				if exists  (SELECT * FROM PersonnelSquadArrangeDetail_View where [PERSONID] = @nPersonID 
					AND ( (@dtStartTime>=[STARTTIME]  AND  @dtStartTime<=[ENDTIME]) 
						OR (@dtEndTime>=[STARTTIME]  AND  @dtEndTime<=[ENDTIME]) OR (@dtStartTime<[STARTTIME] AND @dtEndTime>[ENDTIME])))
					begin
						/*��ȡ���˶�Ӧʱ����ڵ����а��*/
						DECLARE cur1 CURSOR STATIC for SELECT [SQUADID] , [STARTTIME], [ENDTIME] FROM [dbo].PersonnelSquadArrangeDetail_View 
							where [PERSONID] = @nPersonID 
								AND ( (dateadd(day, -1, @dtStartTime)>=[STARTTIME]  AND dateadd(day, -1, @dtStartTime)<=[ENDTIME]) 
									OR (dateadd(day, 1, @dtEndTime)>=[STARTTIME]  AND  dateadd(day, 1, @dtEndTime)<=[ENDTIME])
									OR (dateadd(day, -1, @dtStartTime)<[STARTTIME] AND dateadd(day, 1, @dtEndTime)>[ENDTIME])
									) ORDER BY STARTTIME;
					
						open cur1;
						fetch next from cur1 into @nSquadID, @dtStartTimeSplan , @dtEndTimeSplan;

						if ( @@FETCH_STATUS = 0 )
							set @bContinue = 1;

						DECLARE @bFirstPassDay int,				/*��ǰ�쿪ʼʱ���Ƿ����*/
							@bLastPassDay int, 				/*��ǰ����ֹʱ���Ƿ����*/
							@bAlwaysPassDay int;			/*��ǰ�Ű��Ƿ����*/

						/*����ѭ��ǰ��ʼ��*/
						if @dtStartTimeSplan >= @dtStartTime			/*ǰ��ż�*/
							begin
								select @bAlwaysPassDay = case when datediff( minute, min(STARTTIME), max(ENDTIME)) = 1439 then 1 else 0 end 
									from TSG_View where SQUADID = @nSquadID;
								set @bFirstPassDay = 0;
							end
						else if @dtStartTime between @dtStartTimeSplan and @dtEndTimeSplan		/*��ǰһ��ͬһ�����*/
							begin
								select @bAlwaysPassDay = case when datediff( minute, min(STARTTIME), max(ENDTIME)) = 1439 then 1 else 0 end 
									from TSG_View where SQUADID = @nSquadID;
								set @bFirstPassDay = @bAlwaysPassDay;
							end
						else					--��ǰ��������Ϊһ���¿�ʼ�İ��, ��Ҫ����һ����αȽϵó��Ƿ����
							begin
								FETCH NEXT FROM cur1 into @nSquadIDNext, @dtStartTimeSplanNext , @dtEndTimeSplanNext;
								if ( @@FETCH_STATUS <> 0 )
									set @bContinue = 0;

								if @dtStartTime between @dtStartTimeSplanNext and @dtEndTimeSplanNext		/*��ǰһ�첻ͬ���*/
									begin
										/*�����Ƿ��ڿ���*/
										SELECT @dt1 = max([ENDTIME]) FROM [dbo].TSG_View where [SQUADID] = @nSquadID 
										if (DATEPART(hour, @dt1) = 23  AND  DATEPART(minute, @dt1) = 59)
											begin
												SELECT @dt3 = min([STARTTIME]) FROM [dbo].TSG_View where SQUADID = @nSquadIDNext
												if ( DATEPART(hour, @dt3) = 0  AND  DATEPART(minute, @dt3) = 0 )
													set @bFirstPassDay = 1;
											end
									end
								else
									set @bFirstPassDay = 0;

								set @nSquadID = @nSquadIDNext;
								set @dtStartTimeSplan = @dtStartTimeSplanNext;
								set @dtEndTimeSplan = @dtEndTimeSplanNext;

								select @bAlwaysPassDay = case when datediff( minute, min(STARTTIME), max(ENDTIME)) = 1439 then 1 else 0 end 
									from TSG_View where SQUADID = @nSquadID;
							end

						if  @dtStartTimeSplan <  @dtStartTime	/*���Ű���ʼ�������ڲ�ѯ��ʼ���ڣ�����Ű���ʼ������Ϊ��ѯ��ʼ����*/
							begin
								set @dtStartTimeSplan =  @dtStartTime
							end

						/*if @dtStartTime = @dtStartTimeSplan���*/
						/*ѭ��ǰ��ʼ�����*/
						WHILE @bContinue = 1
							BEGIN
								FETCH NEXT FROM cur1 into @nSquadIDNext, @dtStartTimeSplanNext , @dtEndTimeSplanNext;
								if ( @@FETCH_STATUS <> 0 )
									set @bContinue = 0;

								if exists  (SELECT * FROM [dbo].TSG_View where [SQUADID] = @nSquadID )
									begin
										if exists  (SELECT * FROM [dbo].SQUAD_View where [SQUADID] = @nSquadID )
											begin
												/*��ȡ��α��а��IDΪ@nSquadID�İ�β������������ٵ������������˷������ȵ�*/
												SELECT top 1 @nOndutyRs = [ONDUTY_RS], @nOndutyRe = [ONDUTY_RE], @nOffdutyRs = [OFFDUTY_RS],
														@nOffdutyRe = [OFFDUTY_RE],@nLateMinute = [LATE_MINUTE],@nLeaveMinute = [LEAVE_MINUTE]  
													FROM  [dbo].[Squad] where [SQUADID] = @nSquadID;
							
/*
												if  @dtEndTimeSplan > @dtEndTime	���Ű�����������ڲ�ѯ�������ڣ�����Ű����������Ϊ��ѯ��������
													begin
														set @dtEndTimeSplan = @dtEndTime
													end
*/				
												DECLARE  @dt DATETIME
												set @dt =  @dtStartTimeSplan
												while @dt <= @dtEndTimeSplan
													begin
														if @dt = @dtEndTimeSplan
															begin
																if datediff( day, @dtEndTimeSplan, @dtStartTimeSplanNext ) = 1
																	begin
																		set @bLastPassDay = 0;
																		SELECT top 1  @dt1 = [ENDTIME] FROM [dbo].TSG_View where [SQUADID] = @nSquadID ORDER BY [TSEG_ID] DESC
																		if (DATEPART(hour, @dt1) = 23  AND  DATEPART(minute, @dt1) = 59)
																			begin
																				SELECT top 1 @dt3 = [STARTTIME] FROM [dbo].TSG_View where SQUADID = @nSquadIDNext order BY [TSEG_ID]
																				if  (DATEPART(hour, @dt3) = 0  AND  DATEPART(minute, @dt3) = 0 )
																					set @bLastPassDay = 1;
																			end
																	end
																else
																	set @bLastPassDay = 0;

																select @bAlwaysPassDay = case when datediff( minute, min(STARTTIME), max(ENDTIME)) = 1439 then 1 else 0 end 
																	from TSG_View where SQUADID = @nSquadIDNext;

															end
														else
															set @bLastPassDay = @bAlwaysPassDay;
					
														exec dbo.PRO_QueryCurrentDay @nPersonID, @dt, @nSquadID, @nOndutyRs, @nOndutyRe, @nOffdutyRs, @nOffdutyRe, @nLateMinute, @nLeaveMinute, @bFirstPassDay, @bLastPassDay
														set @dt = DATEADD(day, 1, @dt)  /*ȡ��һ��*/
														if @dt > @dtEndTime break;
															
														set @bFirstPassDay = @bLastPassDay;
													end
											end
										else
											begin
												close cur1
												DEALLOCATE cur1
												return
											end
									end
								set @nSquadID = @nSquadIDNext;
								set @dtStartTimeSplan = @dtStartTimeSplanNext;
								set @dtEndTimeSplan = @dtEndTimeSplanNext;
							END
						close cur1
						DEALLOCATE cur1
					end
			end
	end
GO




