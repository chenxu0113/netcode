insert into SpecialPrivilegeObject values (853, 0, 0) ; 

insert into SpecialPrivilegeObject values (853, 0, 1) ; 

insert into SpecialPrivilegeObject values (853, 0, 2) ; 

insert into SpecialPrivilegeObject values (853, 0, 3) ; 

insert into SpecialPrivilegeObject values (853, 0, 20) ; 

insert into SpecialPrivilegeObject values (853, 0, 21) ; 

insert into SpecialPrivilegeObject values (853, 0, 6) ; 

insert into SpecialPrivilegeObject values (853, 0, 7) ; 

insert into SpecialPrivilegeObject values (853, 3, 0) ; 

insert into SpecialPrivilegeObject values (853, 3, 1) ; 

insert into SpecialPrivilegeObject values (853, 3, 2) ; 

insert into SpecialPrivilegeObject values (853, 3, 3) ; 

insert into SpecialPrivilegeObject values (853, 3, 20) ; 

insert into SpecialPrivilegeObject values (853, 3, 21) ; 

insert into SpecialPrivilegeObject values (853, 12, 0) ; 

insert into SpecialPrivilegeObject values (853, 12, 1) ; 

insert into SpecialPrivilegeObject values (853, 12, 2) ; 

insert into SpecialPrivilegeObject values (853, 12, 3) ; 

insert into SpecialPrivilegeObject values (853, 12, 5) ; 

insert into SpecialPrivilegeObject values (853, 12, 6) ; 

insert into SpecialPrivilegeObject values (853, 12, 7) ; 

insert into SpecialPrivilegeObject values (853, 12, 30) ; 

insert into SpecialPrivilegeObject values (853, 12, 31) ; 

insert into SpecialPrivilegeObject values (853, 12, 32) ; 

insert into SpecialPrivilegeObject values (853, 12, 27) ; 

insert into SpecialPrivilegeObject values (853, 12, 22) ; 

insert into SpecialPrivilegeObject values (853, 12, 23) ; 

insert into SpecialPrivilegeObject values (853, 12, 24) ; 

insert into SpecialPrivilegeObject values (853, 14, 0) ; 

insert into SpecialPrivilegeObject values (853, 14, 1) ; 

insert into SpecialPrivilegeObject values (853, 14, 2) ; 

insert into SpecialPrivilegeObject values (853, 14, 3) ; 

insert into SpecialPrivilegeObject values (853, 16, 0) ; 

insert into SpecialPrivilegeObject values (853, 16, 1) ; 

insert into SpecialPrivilegeObject values (853, 16, 2) ; 

insert into SpecialPrivilegeObject values (853, 16, 3) ; 

insert into SpecialPrivilegeObject values (853, 16, 6) ; 

insert into SpecialPrivilegeObject values (853, 16, 7) ; 

insert into SpecialPrivilegeObject values (853, 38, 0) ; 

insert into SpecialPrivilegeObject values (853, 38, 1) ; 

insert into SpecialPrivilegeObject values (853, 38, 2) ; 

insert into SpecialPrivilegeObject values (853, 38, 3) ; 

insert into SpecialPrivilegeObject values (853, 58, 0) ; 

insert into SpecialPrivilegeObject values (853, 58, 1) ; 

insert into SpecialPrivilegeObject values (853, 58, 2) ; 

insert into SpecialPrivilegeObject values (853, 58, 3) ; 

insert into SpecialPrivilegeObject values (853, 58, 33) ; 

insert into SpecialPrivilegeObject values (853, 58, 34) ; 

insert into SpecialPrivilegeObject values (853, 58, 35) ; 

insert into SpecialPrivilegeObject values (853, 59, 0) ; 

insert into SpecialPrivilegeObject values (853, 59, 1) ; 

insert into SpecialPrivilegeObject values (853, 59, 2) ; 

insert into SpecialPrivilegeObject values (853, 59, 3) ; 

insert into SpecialPrivilegeObject values (853, 59, 20) ; 

insert into SpecialPrivilegeObject values (853, 59, 21) ; 

insert into SpecialPrivilegeObject values (853, 59, 33) ; 

insert into SpecialPrivilegeObject values (853, 60, 0) ; 

insert into SpecialPrivilegeObject values (853, 60, 4) ; 

insert into SpecialPrivilegeObject values (853, 62, 0) ; 

insert into SpecialPrivilegeObject values (853, 62, 1) ; 

insert into SpecialPrivilegeObject values (853, 62, 2) ; 

insert into SpecialPrivilegeObject values (853, 62, 3) ; 

insert into SpecialPrivilegeObject values (853, 62, 20) ; 

insert into SpecialPrivilegeObject values (853, 62, 33) ; 

insert into SpecialPrivilegeObject values (853, 62, 21) ; 

insert into SpecialPrivilegeObject values (853, 63, 0) ; 

insert into SpecialPrivilegeObject values (853, 63, 1) ; 

insert into SpecialPrivilegeObject values (853, 63, 2) ; 

insert into SpecialPrivilegeObject values (853, 63, 3) ; 

insert into SpecialPrivilegeObject values (853, 63, 20) ; 

insert into SpecialPrivilegeObject values (853, 63, 21) ; 

insert into SpecialPrivilegeObject values (853, 63, 33) ; 

insert into SpecialPrivilegeObject values (853, 73, 0) ; 

insert into SpecialPrivilegeObject values (853, 73, 1) ; 

insert into SpecialPrivilegeObject values (853, 73, 2) ; 

insert into SpecialPrivilegeObject values (853, 73, 3) ; 

insert into SpecialPrivilegeObject values (853, 73, 5) ; 

insert into SpecialPrivilegeObject values (853, 73, 19) ; 

insert into SpecialPrivilegeObject values (853, 73, 6) ; 

insert into SpecialPrivilegeObject values (853, 73, 7) ; 

insert into SpecialPrivilegeObject values (853, 73, 8) ; 

insert into SpecialPrivilegeObject values (853, 73, 9) ; 

insert into SpecialPrivilegeObject values (853, 73, 10) ; 

insert into SpecialPrivilegeObject values (853, 73, 11) ; 

insert into SpecialPrivilegeObject values (853, 73, 12) ; 

insert into SpecialPrivilegeObject values (853, 73, 13) ; 

insert into SpecialPrivilegeObject values (853, 73, 30) ; 

insert into SpecialPrivilegeObject values (853, 73, 31) ; 

insert into SpecialPrivilegeObject values (853, 73, 32) ; 

insert into SpecialPrivilegeObject values (853, 73, 27) ; 

insert into SpecialPrivilegeObject values (853, 73, 22) ; 

insert into SpecialPrivilegeObject values (853, 73, 23) ; 

insert into SpecialPrivilegeObject values (853, 73, 24) ; 

insert into SpecialPrivilegeObject values (853, 92, 1) ; 

insert into SpecialPrivilegeObject values (853, 92, 2) ; 

insert into SpecialPrivilegeObject values (853, 92, 3) ; 

insert into SpecialPrivilegeObject values (853, 93, 0) ; 

insert into SpecialPrivilegeObject values (853, 93, 1) ; 

insert into SpecialPrivilegeObject values (853, 93, 2) ; 

insert into SpecialPrivilegeObject values (853, 93, 3) ; 

insert into SpecialPrivilegeObject values (853, 93, 20) ; 

insert into SpecialPrivilegeObject values (853, 93, 21) ; 

insert into SpecialPrivilegeObject values (853, 94, 0) ; 

insert into SpecialPrivilegeObject values (853, 94, 1) ; 

insert into SpecialPrivilegeObject values (853, 94, 2) ; 

insert into SpecialPrivilegeObject values (853, 94, 3) ; 

insert into SpecialPrivilegeObject values (853, 95, 0) ; 

insert into SpecialPrivilegeObject values (853, 95, 1) ; 

insert into SpecialPrivilegeObject values (853, 95, 2) ; 

insert into SpecialPrivilegeObject values (853, 95, 3) ; 

insert into SpecialPrivilegeObject values (853, 96, 0) ; 

insert into SpecialPrivilegeObject values (853, 96, 4) ; 

insert into SpecialPrivilegeObject values (853, 97, 0) ; 

insert into SpecialPrivilegeObject values (853, 97, 1) ; 

insert into SpecialPrivilegeObject values (853, 97, 2) ; 

insert into SpecialPrivilegeObject values (853, 97, 3) ; 

insert into SpecialPrivilegeObject values (853, 113, 0) ; 

insert into SpecialPrivilegeObject values (853, 113, 1) ; 

insert into SpecialPrivilegeObject values (853, 113, 2) ; 

insert into SpecialPrivilegeObject values (853, 113, 3) ; 

insert into SpecialPrivilegeObject values (853, 113, 5) ; 

insert into SpecialPrivilegeObject values (853, 113, 20) ; 

insert into SpecialPrivilegeObject values (853, 113, 21) ; 

insert into SpecialPrivilegeObject values (853, 161, 0) ; 

insert into SpecialPrivilegeObject values (853, 161, 1) ; 

insert into SpecialPrivilegeObject values (853, 161, 2) ; 

insert into SpecialPrivilegeObject values (853, 161, 3) ; 

insert into SpecialPrivilegeObject values (853, 162, 0) ; 

insert into SpecialPrivilegeObject values (853, 162, 1) ; 

insert into SpecialPrivilegeObject values (853, 162, 2) ; 

insert into SpecialPrivilegeObject values (853, 162, 3) ; 

insert into SpecialPrivilegeObject values (853, 163, 0) ; 

insert into SpecialPrivilegeObject values (853, 163, 1) ; 

insert into SpecialPrivilegeObject values (853, 163, 2) ; 

insert into SpecialPrivilegeObject values (853, 163, 3) ; 

insert into SpecialPrivilegeObject values (853, 187, 0) ; 

insert into SpecialPrivilegeObject values (853, 187, 1) ; 

insert into SpecialPrivilegeObject values (853, 187, 2) ; 

insert into SpecialPrivilegeObject values (853, 187, 3) ; 

insert into SpecialPrivilegeObject values (853, 223, 0) ; 

insert into SpecialPrivilegeObject values (853, 223, 1) ; 

insert into SpecialPrivilegeObject values (853, 223, 2) ; 

insert into SpecialPrivilegeObject values (853, 223, 3) ; 

insert into SpecialPrivilegeObject values (853, 350, 0) ; 

insert into SpecialPrivilegeObject values (853, 350, 1) ; 

insert into SpecialPrivilegeObject values (853, 350, 2) ; 

insert into SpecialPrivilegeObject values (853, 350, 3) ; 

insert into SpecialPrivilegeObject values (853, 350, 20) ; 

insert into SpecialPrivilegeObject values (853, 350, 21) ; 

insert into SpecialPrivilegeObject values (853, 351, 0) ; 

insert into SpecialPrivilegeObject values (853, 351, 1) ; 

insert into SpecialPrivilegeObject values (853, 351, 2) ; 

insert into SpecialPrivilegeObject values (853, 351, 3) ; 

insert into SpecialPrivilegeObject values (853, 351, 20) ; 

insert into SpecialPrivilegeObject values (853, 351, 21) ; 

insert into SpecialPrivilegeObject values (853, 352, 0) ; 

insert into SpecialPrivilegeObject values (853, 352, 1) ; 

insert into SpecialPrivilegeObject values (853, 352, 2) ; 

insert into SpecialPrivilegeObject values (853, 352, 3) ; 

insert into SpecialPrivilegeObject values (853, 352, 20) ; 

insert into SpecialPrivilegeObject values (853, 352, 21) ; 

insert into SpecialPrivilegeObject values (853, 353, 0) ; 

insert into SpecialPrivilegeObject values (853, 353, 1) ; 

insert into SpecialPrivilegeObject values (853, 353, 2) ; 

insert into SpecialPrivilegeObject values (853, 353, 3) ; 

insert into SpecialPrivilegeObject values (853, 353, 20) ; 

insert into SpecialPrivilegeObject values (853, 353, 21) ; 

insert into SpecialPrivilegeObject values (853, 354, 0) ; 

insert into SpecialPrivilegeObject values (853, 354, 1) ; 

insert into SpecialPrivilegeObject values (853, 354, 2) ; 

insert into SpecialPrivilegeObject values (853, 354, 3) ; 

insert into SpecialPrivilegeObject values (853, 354, 20) ; 

insert into SpecialPrivilegeObject values (853, 354, 21) ; 

insert into SpecialPrivilegeObject values (853, 355, 0) ; 

insert into SpecialPrivilegeObject values (853, 355, 1) ; 

insert into SpecialPrivilegeObject values (853, 355, 2) ; 

insert into SpecialPrivilegeObject values (853, 355, 3) ; 

insert into SpecialPrivilegeObject values (853, 355, 20) ; 

insert into SpecialPrivilegeObject values (853, 355, 21) ; 

insert into SpecialPrivilegeObject values (853, 400, 0) ; 

insert into SpecialPrivilegeObject values (853, 400, 1) ; 

insert into SpecialPrivilegeObject values (853, 400, 2) ; 

insert into SpecialPrivilegeObject values (853, 400, 3) ; 

insert into SpecialPrivilegeObject values (853, 400, 99) ; 

insert into SpecialPrivilegeObject values (853, 401, 0) ; 

insert into SpecialPrivilegeObject values (853, 401, 1) ; 

insert into SpecialPrivilegeObject values (853, 401, 2) ; 

insert into SpecialPrivilegeObject values (853, 401, 3) ; 

insert into SpecialPrivilegeObject values (853, 401, 20) ; 

insert into SpecialPrivilegeObject values (853, 401, 21) ; 

insert into SpecialPrivilegeObject values (853, 402, 0) ; 

insert into SpecialPrivilegeObject values (853, 402, 1) ; 

insert into SpecialPrivilegeObject values (853, 402, 2) ; 

insert into SpecialPrivilegeObject values (853, 402, 3) ; 

insert into SpecialPrivilegeObject values (853, 403, 0) ; 

insert into SpecialPrivilegeObject values (853, 403, 1) ; 

insert into SpecialPrivilegeObject values (853, 403, 2) ; 

insert into SpecialPrivilegeObject values (853, 403, 3) ; 

insert into SpecialPrivilegeObject values (853, 403, 99) ; 

insert into SpecialPrivilegeObject values (853, 404, 0) ; 

insert into SpecialPrivilegeObject values (853, 404, 1) ; 

insert into SpecialPrivilegeObject values (853, 404, 2) ; 

insert into SpecialPrivilegeObject values (853, 404, 3) ; 

insert into SpecialPrivilegeObject values (853, 404, 99) ; 

insert into SpecialPrivilegeObject values (853, 502, 0) ; 

insert into SpecialPrivilegeObject values (853, 502, 1) ; 

insert into SpecialPrivilegeObject values (853, 502, 2) ; 

insert into SpecialPrivilegeObject values (853, 502, 3) ; 

insert into SpecialPrivilegeObject values (853, 601, 0) ; 

insert into SpecialPrivilegeObject values (853, 601, 1) ; 

insert into SpecialPrivilegeObject values (853, 601, 2) ; 

insert into SpecialPrivilegeObject values (853, 601, 3) ; 

insert into SpecialPrivilegeObject values (853, 601, 20) ; 

insert into SpecialPrivilegeObject values (853, 601, 21) ; 

insert into SpecialPrivilegeObject values (853, 602, 0) ; 

insert into SpecialPrivilegeObject values (853, 700, 0) ; 

insert into SpecialPrivilegeObject values (853, 700, 1) ; 

insert into SpecialPrivilegeObject values (853, 700, 2) ; 

insert into SpecialPrivilegeObject values (853, 700, 3) ; 

insert into SpecialPrivilegeObject values (853, 701, 0) ; 

insert into SpecialPrivilegeObject values (853, 701, 1) ; 

insert into SpecialPrivilegeObject values (853, 701, 2) ; 

insert into SpecialPrivilegeObject values (853, 701, 3) ; 

insert into SpecialPrivilegeObject values (853, 750, 0) ; 

insert into SpecialPrivilegeObject values (853, 750, 1) ; 

insert into SpecialPrivilegeObject values (853, 750, 2) ; 

insert into SpecialPrivilegeObject values (853, 750, 3) ; 

insert into SpecialPrivilegeObject values (853, 800, 0) ; 

insert into SpecialPrivilegeObject values (853, 800, 1) ; 

insert into SpecialPrivilegeObject values (853, 800, 2) ; 

insert into SpecialPrivilegeObject values (853, 800, 3) ; 

insert into SpecialPrivilegeObject values (853, 900, 0) ; 

insert into SpecialPrivilegeObject values (853, 900, 3) ; 

insert into SpecialPrivilegeObject values (853, 900, 5) ; 

insert into SpecialPrivilegeObject values (853, 900, 14) ; 

insert into SpecialPrivilegeObject values (853, 900, 15) ; 

insert into SpecialPrivilegeObject values (853, 900, 16) ; 

insert into SpecialPrivilegeObject values (853, 900, 17) ; 

insert into SpecialPrivilegeObject values (853, 900, 6) ; 

insert into SpecialPrivilegeObject values (853, 900, 7) ; 

insert into SpecialPrivilegeObject values (853, 900, 27) ; 

insert into SpecialPrivilegeObject values (853, 900, 25) ; 

insert into SpecialPrivilegeObject values (853, 900, 26) ; 

insert into SpecialPrivilegeObject values (853, 1000000, 0) ; 

insert into SpecialPrivilegeObject values (853, 1000000, 4) ; 

insert into SpecialPrivilegeObject values (853, 1000001, 0) ; 

insert into SpecialPrivilegeObject values (853, 1000001, 4) ; 

insert into SpecialPrivilegeObject values (853, 1000002, 4) ; 

insert into SpecialPrivilegeObject values (853, 1000003, 4) ; 

insert into SpecialPrivilegeObject values (853, 1000004, 18) ; 

insert into SpecialPrivilegeObject values (853, 1000005, 18) ; 

insert into SpecialPrivilegeObject values (853, 1000006, 18) ; 

insert into SpecialPrivilegeObject values (853, 1000008, 0) ; 

insert into SpecialPrivilegeObject values (853, 1000008, 1) ; 

insert into SpecialPrivilegeObject values (853, 1000008, 2) ; 

insert into SpecialPrivilegeObject values (853, 1000008, 3) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 0) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 1) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 2) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 3) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 20) ; 

insert into SpecialPrivilegeObject values (853, 1000009, 21) ; 


insert into SpecialPrivilegeObject values (854, 0, 0) ; 

insert into SpecialPrivilegeObject values (854, 0, 1) ; 

insert into SpecialPrivilegeObject values (854, 0, 2) ; 

insert into SpecialPrivilegeObject values (854, 0, 3) ; 

insert into SpecialPrivilegeObject values (854, 3, 0) ; 

insert into SpecialPrivilegeObject values (854, 3, 1) ; 

insert into SpecialPrivilegeObject values (854, 3, 2) ; 

insert into SpecialPrivilegeObject values (854, 3, 3) ; 

insert into SpecialPrivilegeObject values (854, 3, 20) ; 

insert into SpecialPrivilegeObject values (854, 3, 21) ; 

insert into SpecialPrivilegeObject values (854, 12, 0) ; 

insert into SpecialPrivilegeObject values (854, 12, 1) ; 

insert into SpecialPrivilegeObject values (854, 12, 2) ; 

insert into SpecialPrivilegeObject values (854, 12, 3) ; 

insert into SpecialPrivilegeObject values (854, 12, 5) ; 

insert into SpecialPrivilegeObject values (854, 12, 6) ; 

insert into SpecialPrivilegeObject values (854, 12, 7) ; 

insert into SpecialPrivilegeObject values (854, 12, 30) ; 

insert into SpecialPrivilegeObject values (854, 12, 31) ; 

insert into SpecialPrivilegeObject values (854, 12, 32) ; 

insert into SpecialPrivilegeObject values (854, 12, 27) ; 

insert into SpecialPrivilegeObject values (854, 12, 22) ; 

insert into SpecialPrivilegeObject values (854, 12, 23) ; 

insert into SpecialPrivilegeObject values (854, 12, 24) ; 

insert into SpecialPrivilegeObject values (854, 14, 0) ; 

insert into SpecialPrivilegeObject values (854, 14, 1) ; 

insert into SpecialPrivilegeObject values (854, 14, 2) ; 

insert into SpecialPrivilegeObject values (854, 14, 3) ; 

insert into SpecialPrivilegeObject values (854, 62, 0) ; 

insert into SpecialPrivilegeObject values (854, 62, 1) ; 

insert into SpecialPrivilegeObject values (854, 62, 2) ; 

insert into SpecialPrivilegeObject values (854, 62, 3) ; 

insert into SpecialPrivilegeObject values (854, 63, 0) ; 

insert into SpecialPrivilegeObject values (854, 63, 1) ; 

insert into SpecialPrivilegeObject values (854, 63, 2) ; 

insert into SpecialPrivilegeObject values (854, 63, 3) ; 

insert into SpecialPrivilegeObject values (854, 63, 20) ; 

insert into SpecialPrivilegeObject values (854, 63, 21) ; 

insert into SpecialPrivilegeObject values (854, 73, 0) ; 

insert into SpecialPrivilegeObject values (854, 73, 1) ; 

insert into SpecialPrivilegeObject values (854, 73, 2) ; 

insert into SpecialPrivilegeObject values (854, 73, 3) ; 

insert into SpecialPrivilegeObject values (854, 73, 5) ; 

insert into SpecialPrivilegeObject values (854, 73, 19) ; 

insert into SpecialPrivilegeObject values (854, 73, 6) ; 

insert into SpecialPrivilegeObject values (854, 73, 7) ; 

insert into SpecialPrivilegeObject values (854, 73, 8) ; 

insert into SpecialPrivilegeObject values (854, 73, 9) ; 

insert into SpecialPrivilegeObject values (854, 73, 10) ; 

insert into SpecialPrivilegeObject values (854, 73, 11) ; 

insert into SpecialPrivilegeObject values (854, 73, 12) ; 

insert into SpecialPrivilegeObject values (854, 73, 13) ; 

insert into SpecialPrivilegeObject values (854, 73, 30) ; 

insert into SpecialPrivilegeObject values (854, 73, 31) ; 

insert into SpecialPrivilegeObject values (854, 73, 32) ; 

insert into SpecialPrivilegeObject values (854, 73, 27) ; 

insert into SpecialPrivilegeObject values (854, 73, 22) ; 

insert into SpecialPrivilegeObject values (854, 73, 23) ; 

insert into SpecialPrivilegeObject values (854, 73, 24) ; 

insert into SpecialPrivilegeObject values (854, 223, 0) ; 

insert into SpecialPrivilegeObject values (854, 223, 1) ; 

insert into SpecialPrivilegeObject values (854, 223, 2) ; 

insert into SpecialPrivilegeObject values (854, 223, 3) ; 

insert into SpecialPrivilegeObject values (854, 350, 0) ; 

insert into SpecialPrivilegeObject values (854, 350, 1) ; 

insert into SpecialPrivilegeObject values (854, 350, 2) ; 

insert into SpecialPrivilegeObject values (854, 350, 3) ; 

insert into SpecialPrivilegeObject values (854, 351, 0) ; 

insert into SpecialPrivilegeObject values (854, 351, 1) ; 

insert into SpecialPrivilegeObject values (854, 351, 2) ; 

insert into SpecialPrivilegeObject values (854, 351, 3) ; 

insert into SpecialPrivilegeObject values (854, 352, 0) ; 

insert into SpecialPrivilegeObject values (854, 352, 1) ; 

insert into SpecialPrivilegeObject values (854, 352, 2) ; 

insert into SpecialPrivilegeObject values (854, 352, 3) ; 

insert into SpecialPrivilegeObject values (854, 353, 0) ; 

insert into SpecialPrivilegeObject values (854, 353, 1) ; 

insert into SpecialPrivilegeObject values (854, 353, 2) ; 

insert into SpecialPrivilegeObject values (854, 353, 3) ; 

insert into SpecialPrivilegeObject values (854, 354, 0) ; 

insert into SpecialPrivilegeObject values (854, 354, 1) ; 

insert into SpecialPrivilegeObject values (854, 354, 2) ; 

insert into SpecialPrivilegeObject values (854, 354, 3) ; 

insert into SpecialPrivilegeObject values (854, 355, 0) ; 

insert into SpecialPrivilegeObject values (854, 355, 1) ; 

insert into SpecialPrivilegeObject values (854, 355, 2) ; 

insert into SpecialPrivilegeObject values (854, 355, 3) ; 

insert into SpecialPrivilegeObject values (854, 400, 0) ; 

insert into SpecialPrivilegeObject values (854, 400, 1) ; 

insert into SpecialPrivilegeObject values (854, 400, 2) ; 

insert into SpecialPrivilegeObject values (854, 400, 3) ; 

insert into SpecialPrivilegeObject values (854, 400, 99) ; 

insert into SpecialPrivilegeObject values (854, 401, 0) ; 

insert into SpecialPrivilegeObject values (854, 401, 1) ; 

insert into SpecialPrivilegeObject values (854, 401, 2) ; 

insert into SpecialPrivilegeObject values (854, 401, 3) ; 

insert into SpecialPrivilegeObject values (854, 900, 0) ; 

insert into SpecialPrivilegeObject values (854, 900, 3) ; 

insert into SpecialPrivilegeObject values (854, 900, 14) ; 

insert into SpecialPrivilegeObject values (854, 900, 15) ; 

insert into SpecialPrivilegeObject values (854, 900, 16) ; 

insert into SpecialPrivilegeObject values (854, 900, 17) ; 

insert into SpecialPrivilegeObject values (854, 900, 6) ; 

insert into SpecialPrivilegeObject values (854, 900, 7) ; 

insert into SpecialPrivilegeObject values (854, 900, 27) ; 

insert into SpecialPrivilegeObject values (854, 900, 25) ; 

insert into SpecialPrivilegeObject values (854, 900, 26) ; 

insert into SpecialPrivilegeObject values (857, 0, 0) ; 

insert into SpecialPrivilegeObject values (857, 0, 1) ; 

insert into SpecialPrivilegeObject values (857, 0, 2) ; 

insert into SpecialPrivilegeObject values (857, 0, 3) ; 

insert into SpecialPrivilegeObject values (857, 3, 0) ; 

insert into SpecialPrivilegeObject values (857, 3, 1) ; 

insert into SpecialPrivilegeObject values (857, 3, 2) ; 

insert into SpecialPrivilegeObject values (857, 3, 3) ; 

insert into SpecialPrivilegeObject values (857, 3, 20) ; 

insert into SpecialPrivilegeObject values (857, 3, 21) ; 

insert into SpecialPrivilegeObject values (857, 58, 0) ; 

insert into SpecialPrivilegeObject values (857, 58, 1) ; 

insert into SpecialPrivilegeObject values (857, 58, 2) ; 

insert into SpecialPrivilegeObject values (857, 58, 3) ; 

insert into SpecialPrivilegeObject values (857, 59, 0) ; 

insert into SpecialPrivilegeObject values (857, 59, 1) ; 

insert into SpecialPrivilegeObject values (857, 59, 2) ; 

insert into SpecialPrivilegeObject values (857, 59, 3) ; 

insert into SpecialPrivilegeObject values (857, 59, 20) ; 

insert into SpecialPrivilegeObject values (857, 59, 21) ; 

insert into SpecialPrivilegeObject values (857, 92, 1) ; 

insert into SpecialPrivilegeObject values (857, 92, 2) ; 

insert into SpecialPrivilegeObject values (857, 92, 3) ; 

insert into SpecialPrivilegeObject values (857, 93, 0) ; 

insert into SpecialPrivilegeObject values (857, 93, 1) ; 

insert into SpecialPrivilegeObject values (857, 93, 2) ; 

insert into SpecialPrivilegeObject values (857, 93, 3) ; 

insert into SpecialPrivilegeObject values (857, 93, 20) ; 

insert into SpecialPrivilegeObject values (857, 93, 21) ; 

insert into SpecialPrivilegeObject values (857, 94, 0) ; 

insert into SpecialPrivilegeObject values (857, 94, 1) ; 

insert into SpecialPrivilegeObject values (857, 94, 2) ; 

insert into SpecialPrivilegeObject values (857, 94, 3) ; 

insert into SpecialPrivilegeObject values (857, 95, 0) ; 

insert into SpecialPrivilegeObject values (857, 95, 1) ; 

insert into SpecialPrivilegeObject values (857, 95, 2) ; 

insert into SpecialPrivilegeObject values (857, 95, 3) ; 

insert into SpecialPrivilegeObject values (857, 96, 0) ; 

insert into SpecialPrivilegeObject values (857, 96, 4) ; 

insert into SpecialPrivilegeObject values (857, 97, 0) ; 

insert into SpecialPrivilegeObject values (857, 97, 1) ; 

insert into SpecialPrivilegeObject values (857, 97, 2) ; 

insert into SpecialPrivilegeObject values (857, 97, 3) ; 

insert into SpecialPrivilegeObject values (857, 1000005, 18) ; 

insert into SpecialPrivilegeObject values (855, 0, 0) ; 

insert into SpecialPrivilegeObject values (855, 0, 1) ; 

insert into SpecialPrivilegeObject values (855, 0, 2) ; 

insert into SpecialPrivilegeObject values (855, 0, 3) ; 

insert into SpecialPrivilegeObject values (855, 3, 0) ; 

insert into SpecialPrivilegeObject values (855, 3, 1) ; 

insert into SpecialPrivilegeObject values (855, 3, 2) ; 

insert into SpecialPrivilegeObject values (855, 3, 3) ; 

insert into SpecialPrivilegeObject values (855, 3, 20) ; 

insert into SpecialPrivilegeObject values (855, 3, 21) ; 

insert into SpecialPrivilegeObject values (855, 38, 0) ; 

insert into SpecialPrivilegeObject values (855, 38, 1) ; 

insert into SpecialPrivilegeObject values (855, 38, 2) ; 

insert into SpecialPrivilegeObject values (855, 38, 3) ; 

insert into SpecialPrivilegeObject values (855, 58, 0) ; 

insert into SpecialPrivilegeObject values (855, 58, 1) ; 

insert into SpecialPrivilegeObject values (855, 58, 2) ; 

insert into SpecialPrivilegeObject values (855, 58, 3) ; 

insert into SpecialPrivilegeObject values (855, 59, 0) ; 

insert into SpecialPrivilegeObject values (855, 59, 1) ; 

insert into SpecialPrivilegeObject values (855, 59, 2) ; 

insert into SpecialPrivilegeObject values (855, 59, 3) ; 

insert into SpecialPrivilegeObject values (855, 59, 20) ; 

insert into SpecialPrivilegeObject values (855, 59, 21) ; 

insert into SpecialPrivilegeObject values (855, 62, 0) ; 

insert into SpecialPrivilegeObject values (855, 62, 1) ; 

insert into SpecialPrivilegeObject values (855, 62, 2) ; 

insert into SpecialPrivilegeObject values (855, 62, 3) ; 

insert into SpecialPrivilegeObject values (855, 502, 0) ; 

insert into SpecialPrivilegeObject values (855, 502, 1) ; 

insert into SpecialPrivilegeObject values (855, 502, 2) ; 

insert into SpecialPrivilegeObject values (855, 502, 3) ; 

insert into SpecialPrivilegeObject values (855, 502, 200) ; 

insert into SpecialPrivilegeObject values (855, 502, 201) ; 

insert into SpecialPrivilegeObject values (855, 502, 202) ; 

insert into SpecialPrivilegeObject values (855, 601, 0) ; 

insert into SpecialPrivilegeObject values (855, 601, 1) ; 

insert into SpecialPrivilegeObject values (855, 601, 2) ; 

insert into SpecialPrivilegeObject values (855, 601, 3) ; 

insert into SpecialPrivilegeObject values (855, 602, 0) ; 

insert into SpecialPrivilegeObject values (855, 1902, 0) ; 

insert into SpecialPrivilegeObject values (855, 1902, 1) ; 

insert into SpecialPrivilegeObject values (855, 1902, 2) ; 

insert into SpecialPrivilegeObject values (855, 1902, 3) ; 

insert into SpecialPrivilegeObject values (855, 1903, 0) ; 

insert into SpecialPrivilegeObject values (855, 1903, 1) ; 

insert into SpecialPrivilegeObject values (855, 1903, 2) ; 

insert into SpecialPrivilegeObject values (855, 1903, 3) ; 

insert into SpecialPrivilegeObject values (858, 0, 0) ; 

insert into SpecialPrivilegeObject values (858, 0, 1) ; 

insert into SpecialPrivilegeObject values (858, 0, 2) ; 

insert into SpecialPrivilegeObject values (858, 0, 3) ; 

insert into SpecialPrivilegeObject values (858, 3, 0) ; 

insert into SpecialPrivilegeObject values (858, 3, 1) ; 

insert into SpecialPrivilegeObject values (858, 3, 2) ; 

insert into SpecialPrivilegeObject values (858, 3, 3) ; 

insert into SpecialPrivilegeObject values (858, 3, 20) ; 

insert into SpecialPrivilegeObject values (858, 3, 21) ; 

insert into SpecialPrivilegeObject values (858, 58, 0) ; 

insert into SpecialPrivilegeObject values (858, 58, 1) ; 

insert into SpecialPrivilegeObject values (858, 58, 2) ; 

insert into SpecialPrivilegeObject values (858, 58, 3) ; 

insert into SpecialPrivilegeObject values (858, 59, 0) ; 

insert into SpecialPrivilegeObject values (858, 59, 1) ; 

insert into SpecialPrivilegeObject values (858, 59, 2) ; 

insert into SpecialPrivilegeObject values (858, 59, 3) ; 

insert into SpecialPrivilegeObject values (858, 59, 20) ; 

insert into SpecialPrivilegeObject values (858, 59, 21) ; 

insert into SpecialPrivilegeObject values (858, 62, 0) ; 

insert into SpecialPrivilegeObject values (858, 62, 1) ; 

insert into SpecialPrivilegeObject values (858, 62, 2) ; 

insert into SpecialPrivilegeObject values (858, 62, 3) ; 

insert into SpecialPrivilegeObject values (858, 63, 0) ; 

insert into SpecialPrivilegeObject values (858, 63, 1) ; 

insert into SpecialPrivilegeObject values (858, 63, 2) ; 

insert into SpecialPrivilegeObject values (858, 63, 3) ; 

insert into SpecialPrivilegeObject values (858, 63, 20) ; 

insert into SpecialPrivilegeObject values (858, 63, 21) ; 

insert into SpecialPrivilegeObject values (858, 1000000, 0) ; 

insert into SpecialPrivilegeObject values (858, 1000000, 4) ; 

insert into SpecialPrivilegeObject values (858, 1000001, 0) ; 

insert into SpecialPrivilegeObject values (858, 1000001, 4) ; 

insert into SpecialPrivilegeObject values (858, 1000002, 4) ; 

insert into SpecialPrivilegeObject values (858, 1000003, 4) ; 

insert into SpecialPrivilegeObject values (858, 1000004, 18) ; 

insert into SpecialPrivilegeObject values (858, 1000005, 18) ; 



