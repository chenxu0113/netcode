delete from InherentDevicePointClass
go

if not  exists(select * from InherentDevicePointClass where nid=0x80000001)
insert into dbo.InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(0x80000001,800,0,getdate(),getdate(),N'����',N'����',N'')

if not  exists(select * from InherentDevicePointClass where nid=0x80000002)
insert into dbo.InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(0x80000002,800,0,getdate(),getdate(),N'��ѹ',N'��ѹ',N'')

if not  exists(select * from InherentDevicePointClass where nid=0x80000003)
insert into dbo.InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(0x80000003,800,0,getdate(),getdate(),N'����',N'����',N'')

 

 