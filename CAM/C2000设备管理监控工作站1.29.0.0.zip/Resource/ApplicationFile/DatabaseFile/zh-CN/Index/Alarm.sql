
IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'Devive_IDEX')
begin
    CREATE INDEX [Devive_IDEX] ON [dbo].[Alarm] ([nDevice]) 
end

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'OccurTime_Index')
begin
   CREATE INDEX [OccurTime_Index] ON [dbo].[Alarm] ([dtOccurTime])
end

if exists (select * from sysindexes where id=Object_Id(N'Alarm') and name='Alarm_INDEX')
begin
   drop index Alarm.Alarm_INDEX
end

go


if exists (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'PK_Alarm')
begin     
    alter table Alarm drop constraint pk_Alarm 	
end
go


alter  table dbo.Alarm  alter column  nID bigint   not null
go


ALTER TABLE Alarm ADD  CONSTRAINT PK_Alarm PRIMARY KEY (nID,nServerNO)
go

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'Controller_Index')
begin
   CREATE INDEX [Controller_Index] ON [dbo].[Alarm] ([nController])
end

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'Controller_OccurTime_Index')
begin
   CREATE INDEX [Controller_OccurTime_Index] ON [dbo].[Alarm] ([nController], dtOccurTime)
end

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'Controller_ClearTime_Index')
begin
   CREATE INDEX [Controller_ClearTime_Index] ON [dbo].[Alarm] ([nController], dtClearTime)
end

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[Alarm]') AND name = N'AlarmSource_IDEX')
begin
    CREATE INDEX [AlarmSource_IDEX] ON [dbo].[Alarm] ([nAlarmSource]) 
end
