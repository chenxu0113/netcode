IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[ExceptionInfo]') AND name = N'ExceptionInfo_Device_Index')
begin
   CREATE INDEX [ExceptionInfo_Device_Index] ON [dbo].[ExceptionInfo] (nMacAddress)
end