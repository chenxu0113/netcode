IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[AlarmNotify]') AND name = N'AlarmNotify_AlarmID_Index')
begin
   CREATE INDEX [AlarmNotify_AlarmID_Index] ON [dbo].[AlarmNotify] (nAlarmID)
end

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[AlarmNotify]') AND name = N'AlarmNotify_nCardHolder_Time_Index')
begin
   CREATE INDEX [AlarmNotify_nCardHolder_Time_Index] ON [dbo].[AlarmNotify] (nCardHolder, dtTime)
end
