

IF not EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[dbo].[PointValue]') AND name = N'PointValue_Index')
begin
CREATE CLUSTERED INDEX [PointValue_Index] ON [dbo].[PointValue] 
(
	[nDeviceID] ASC,
	[date] ASC
)
end