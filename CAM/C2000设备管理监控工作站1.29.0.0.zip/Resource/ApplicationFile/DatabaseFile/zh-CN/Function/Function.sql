/*
�޸�ԭ��Ȩ�޶��󱨱���ѯ����㹦��
�޸�ʱ�䣺2008-09-25
�޸��ˣ�  Lbs	
add in Version: V1.2.0.1
*/
GO
IF EXISTS (SELECT name FROM sysobjects WHERE name = 'GetObjectPath' AND type = 'FN')   
	DROP FUNCTION GetObjectPath
GO

CREATE FUNCTION dbo.GetObjectPath(@nClassID int, @nID int)
RETURNS VARCHAR(1000)
AS
BEGIN
	declare @strPath VARCHAR(1000);
	declare @strName VARCHAR(50);
	declare @nContainerClassID int,@nContainerID int;
	
	SELECT top 1
		   @nContainerClassID = nContainerClassID, 
		   @nContainerID = nContainerID 
	FROM Container 
	WHERE nSubClassID = @nClassID AND nSubObjectID = @nID;
	if @@ROWCOUNT <> 0
		set @strPath = dbo.GetObjectPath(@nContainerClassID, @nContainerID);
	else	
	begin
		-- ����˫�����������ӳ�丸·��
		SELECT top 1
			   @nContainerClassID = nContainerClassID, 
			   @nContainerID = nContainerID 
		FROM DoubleControllerManager 
		WHERE nSubClassID = @nClassID AND nSubObjectID = @nID
		  and nMasterDevice = 1;
		  
		if @@ROWCOUNT <> 0
		begin
			set @strPath = dbo.GetObjectPath(@nContainerClassID, @nContainerID);
			return @strPath;
		end
		else
			set @strPath = '';
	end
	
	if @nClassID = 58
		SELECT @strName = isnull(strName,'') FROM Personnel WHERE nID = @nID;
	else	
		SELECT @strName = isnull(strFullName,'') FROM NameObject WHERE nID = @nID;
	if @@ROWCOUNT = 0
		set @strName = '';
				
	if @nClassID in (15, 75)
		return @strPath;
		
	if @nClassID = 0
		return '';
		
	return @strPath + '\' + isnull(@strName,'');
END
GO

-------------------------------------------------------------------------------------

IF EXISTS (SELECT name FROM sysobjects WHERE name = 'GetObjectPathByID' AND type = 'FN')   
	DROP FUNCTION GetObjectPathByID
GO

CREATE FUNCTION GetObjectPathByID
	( @nID INT )
	RETURNS VARCHAR(1000)
AS
BEGIN
	DECLARE @nClassID int ;
	SELECT @nClassID = nClassID FROM NameObject WHERE nID = @nID;
	if @@ROWCOUNT = 0
		return '';

	return dbo.GetObjectPath(@nClassID, @nID);
END
GO




---------------------------------------------------------------------------------------
/*
�޸ļ�¼:	ʱ��: 2010-06-10
�޸���:	�ֱ�
�޸�����: ����ʱ���ȡ�豸��ֵ
*/

IF EXISTS (SELECT name FROM sysobjects WHERE name = 'GetDeviceValueByTime' AND type = 'FN')   
	DROP FUNCTION GetDeviceValueByTime
GO
CREATE FUNCTION GetDeviceValueByTime(@iType INT,@iDeviceID INT,
	@dtStartDate DATETIME,-- ��ʼ��ʱ������
	@dtEndDate DATETIME,-- ������ʱ������
	@dtStartTime DATETIME, -- Ҫ��ʼ�����ʱ���
	@dtEndTime DATETIME)-- Ҫ�������ʱ���
RETURNS FLOAT
AS
BEGIN
	DECLARE @iResult FLOAT
	SET @iResult = 0 
	DECLARE cur_table CURSOR LOCAL FOR
	SELECT nDeviceID, [date], VALUE
	FROM PointValue
	WHERE [value]>=0
	AND nDeviceID = @iDeviceID
	AND nIndex = @iType
	AND [value] IS NOT NULL
	-- ���ڷ�Χ
	AND (YEAR([date])*10000+MONTH([date])*100+DAY([date])) >= (YEAR(@dtStartDate)*10000+MONTH(@dtStartDate)*100+DAY(@dtStartDate))
	AND (YEAR([date])*10000+MONTH([date])*100+DAY([date])) <= (YEAR(@dtEndDate)*10000+MONTH(@dtEndDate)*100+DAY(@dtEndDate))
	-- ʱ�䷶Χ
	AND (DATEPART(hh, [date])*10000+DATEPART(mi, [date])*100+DATEPART(ss, [date])) >= (DATEPART(hh, @dtStartTime)*10000+DATEPART(mi, @dtStartTime)*100+DATEPART(ss, @dtStartTime))
	AND (DATEPART(hh, [date])*10000+DATEPART(mi, [date])*100+DATEPART(ss, [date])) <= (DATEPART(hh, @dtEndTime)*10000+DATEPART(mi, @dtEndTime)*100+DATEPART(ss, @dtEndTime))
	
	ORDER BY nDeviceID ASC, [date] DESC
	
	--DECLARE @table TABLE (
	--	DEVICE_ID INT,
	--	MAX_VALUE FLOAT
	--)
	DECLARE @pre_DID FLOAT
	DECLARE @cur_DID FLOAT
	DECLARE @pre_DATE DATETIME
	DECLARE @cur_DATE DATETIME
	DECLARE @pre_VAL INT
	DECLARE @cur_VAL INT
	DECLARE @total INT
	SET @total = 0
	
	-- ö�ٸ���ֵ
	OPEN cur_table
	FETCH NEXT FROM cur_table INTO @cur_DID, @cur_DATE, @cur_VAL
	WHILE @@FETCH_STATUS = 0
	BEGIN
 
	IF @pre_DID IS NOT NULL AND @pre_DID<>@cur_DID
	BEGIN
		--INSERT INTO @table(DEVICE_ID, MAX_VALUE) VALUES(@pre_DID, @total)
		SET @total = 0
		SET @pre_DATE = NULL
		SET @pre_VAL = NULL
	END		
	
	IF DATEPART(hh, @dtStartTime)<>0 OR DATEPART(mi, @dtStartTime)<>0 OR DATEPART(ss, @dtStartTime)<>0 OR DATEPART(hh, @dtEndTime)<>23 OR DATEPART(mi, @dtEndTime)<>59 OR DATEPART(ss, @dtEndTime)<59
	BEGIN
	   IF @pre_DATE IS NOT NULL AND (YEAR(@pre_DATE)<>YEAR(@cur_DATE) OR MONTH(@pre_DATE)<>MONTH(@cur_DATE) OR DAY(@pre_DATE)<>DAY(@cur_DATE))
	      BEGIN
	         SET @pre_VAL = NULL
	      END
	END

	IF @pre_VAL IS NOT NULL
	BEGIN
	        --PRINT '��ֵ = '+ CAST(@total AS varchar(10))+ ' ��ǰֵ = '+ CAST(@cur_VAL AS varchar(10))+' ֮ǰֵ = ' + CAST(@pre_VAL AS varchar(10))

		-- ���ǰһ��ֵ�ȵ�ǰֵС����ǰֵ��Ϊ0
		IF @pre_VAL < @cur_VAL
		BEGIN
			SET @total = @total + (@pre_VAL - 0)
		END
		ELSE
		BEGIN
			SET @total = @total + (@pre_VAL - @cur_VAL)
		END	 
	END
	
	SET @pre_DID = @cur_DID
	SET @pre_DATE = @cur_DATE
	SET @pre_VAL = @cur_VAL	
	FETCH NEXT FROM cur_table INTO @cur_DID, @cur_DATE, @cur_VAL
	END
	--INSERT INTO @table(DEVICE_ID, MAX_VALUE) VALUES(@cur_DID, @total)
	DEALLOCATE cur_table
	SET @iResult = @total
	return @iResult
END
GO


---------------------------------------------------------------------------------------
/*
�޸ļ�¼:	ʱ��: 2011-03-12
�޸���:	ղ����
�޸�����: ͨ�������HiCardNo��lowCardNo�ϲ���һ������
*/
IF EXISTS (SELECT name FROM sysobjects WHERE name = 'GetCardNoByHiAndLowCardNo' AND type = 'FN')   
	DROP FUNCTION GetCardNoByHiAndLowCardNo
GO

IF EXISTS (SELECT name FROM sysobjects WHERE name = 'MergeCardNO' AND type = 'FN')   
BEGIN
	DROP FUNCTION MergeCardNO
END
GO  
CREATE FUNCTION MergeCardNO
	( @nHiCardNo INT,@nLoCardNo INT)
	RETURNS BigINt
AS
BEGIN
	DECLARE @nCardNo BigINT ;

    set @nCardNo=CAST(@nHiCardNo AS Bigint) * CAST(4294967296 AS Bigint);
 
    if @nLoCardNo >= 0
        begin
			set @nCardNo=@nCardNo+@nLoCardNo
        end
    else
		begin
			set @nCardNo=@nCardNo + 4294967296 + CAST(@nLoCardNo AS bigint)
        end
   
    return @nCardNo
END
GO