IF not EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[LinkageTemplate]') AND type in (N'U'))
begin
	cREATE TABLE [dbo].[LinkageTemplate](
	[nID] [int] NOT NULL,
	[nServerNO] [int] Default 0,
	[sTemplateName] [nvarchar](50),
	[nType] [int] not NULL,
	[Delay] [int] not NULL,
	[sExpresstion] [nvarchar](1000) NULL,
	[sEpParamDes] [nvarchar](1000) NULL,
	[sAction] [nvarchar](1000) not NULL,

 	CONSTRAINT [PK_LinkageTemplate] PRIMARY KEY CLUSTERED 
	(
		[nID] ASC
	)ON [PRIMARY]
	) 	

end

alter table [LinkageTemplate] alter column [nServerNO] int not null


IF EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[LinkageTemplate]') AND name = N'PK_LinkageTemplate')
begin
   ALTER TABLE [LinkageTemplate] DROP CONSTRAINT PK_LinkageTemplate
end
GO

ALTER TABLE [LinkageTemplate] ADD  CONSTRAINT PK_LinkageTemplate PRIMARY KEY CLUSTERED 
(
	[nID] ASC,
	[nServerNO] ASC
)
GO




