
/****** ����:  Table [dbo].[NameObject]    �ű�����: 06/24/2010 16:34:36 ******/

IF not EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[NameObject]') AND type in (N'U'))
begin
cREATE TABLE [dbo].[NameObject](
	[nID] [int] NOT NULL,
	[nClassID] [int] NULL,
	[nAttr] [int] NULL,
	[strName] [nvarchar](50) NULL,
	[strFullName] [nvarchar](50) NULL,
	[strDescription] [nvarchar](50) NULL,
	[nVersion] [int] NULL,
	[bPrivilegeInherit] [bit] NULL,
	[varData] [image] NULL,
	[dtCreateTime] [datetime] NULL,
	[dtModifyTime] [datetime] NULL,
	[varDvPtData] [image] NULL,
 CONSTRAINT [PK_NameObject] PRIMARY KEY CLUSTERED 
(
	[nID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

end
GO

ALTER TABLE NameObject ALTER COLUMN strName NVARCHAR(50);
ALTER TABLE NameObject ALTER COLUMN strFullName NVARCHAR(50);
ALTER TABLE NameObject ALTER COLUMN strDescription NVARCHAR(50);

/*
�޸�ԭ�򣺼�����������ֶ�
�޸�ʱ�䣺2010-12-21
�޸��ˣ�  LinBin	
*/
if not exists ( select name from syscolumns where OBJECT_ID(N'NameObject') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'ObjectAttribute' )
    alter table dbo.NameObject add ObjectAttribute image

/*
�޸�ԭ�򣺼�����������ֶ�
�޸�ʱ�䣺2011-4-13
�޸��ˣ�  ��ΰ��	
*/
if not exists ( select name from syscolumns where OBJECT_ID(N'NameObject') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'ObjectProperty' )
    alter table dbo.NameObject add ObjectProperty image NULL



/*
�޸�ԭ��ȥ��TRContainerDelete������
�޸�ʱ�䣺2008-09-19
�޸��ˣ� 
add in Version: V1.2.0.1
*/
IF EXISTS (SELECT name FROM sysobjects
      WHERE name = 'TRContainerDelete' AND type = 'TR')
   DROP TRIGGER TRContainerDelete
GO

IF EXISTS (SELECT name FROM sysobjects
      WHERE name = 'TRNameObjectDelete' AND type = 'TR')
   DROP TRIGGER TRNameObjectDelete
GO

CREATE TRIGGER TRNameObjectDelete
	on NameObject 
	WITH ENCRYPTION 
	for delete 
AS
begin
declare @DeletedClassID int
select @DeletedClassID = nClassID from deleted


----ɾ��������йصİ�ȫ�󶨶���
	delete SecurityObjectBind from SecurityObjectBind, deleted 
		where nObjectID = deleted.nID AND SecurityObjectBind.nClassID = deleted.nClassID


----ɾ����ͼ��Ϣ��ĵ��豸
	delete MAP_INFO from  MAP_INFO,deleted  where MAP_INFO.nChildID = deleted.nID AND MAP_INFO.nChildClassID = deleted.nClassID

end
GO



/*
�޸�ԭ�������豸��������
�޸�ʱ�䣺2008-07-22
�޸��ˣ�  xiehuanbin	
*/
--�����豸��������
if not exists ( select name from syscolumns where OBJECT_ID(N'NameObject') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'varDvPtData' )
    alter table dbo.NameObject add varDvPtData image


/*
�޸ļ�¼:	ʱ��: 2010-06-10   �°汾�� 2.3.1.0    �ɰ汾��2.3.0.2
�޸���:	��ΰ��	
�޸�����: ��NameObject����Personnel����nID�е�IDENTIFY����ȥ��,����ֻ�޸�NameObject��
*/
if COLUMNPROPERTY( OBJECT_ID(N'NameObject'), 'nID' , 'IsIdentity' ) = 1
begin
CREATE TABLE dbo.Tmp_NameObject
	(
	nID int NOT NULL,
	nClassID int NOT NULL,
	nAttr int NULL,
	strName nvarchar(50) NULL,
	strFullName nvarchar(50) NULL,
	strDescription nvarchar(50) NULL,
	nVersion int NULL,
	bPrivilegeInherit bit NULL,
	varData image NULL,
	dtCreateTime datetime NULL,
	dtModifyTime datetime NULL,
	varDvPtData image NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]

IF EXISTS(SELECT * FROM dbo.NameObject)
	 EXEC('INSERT INTO dbo.Tmp_NameObject (nID, nClassID, nServerNO ,nAttr, strName, strFullName, strDescription, nVersion, bPrivilegeInherit, varData, dtCreateTime, dtModifyTime, varDvPtData)
		SELECT nID, nClassID, 0 as nServerNO, nAttr, strName, strFullName, strDescription, nVersion, bPrivilegeInherit, varData, dtCreateTime, dtModifyTime, varDvPtData FROM dbo.NameObject TABLOCKX')

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlarmCondition]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AlarmCondition_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[AlarmCondition]'))
	begin
		ALTER TABLE dbo.AlarmCondition drop CONSTRAINT  FK_AlarmCondition_NameObject
	end
end



IF  EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'[dbo].[AlarmEvents]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[FK_AlarmEvents_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[AlarmEvents]'))
	begin
	ALTER TABLE AlarmEvents drop CONSTRAINT  FK_AlarmEvents_NameObject
	end
end



IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[AlarmPoints]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[FK_AlarmPoints_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[AlarmPoints]'))
	begin
	ALTER TABLE AlarmPoints drop CONSTRAINT  FK_AlarmPoints_NameObject
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[TemplateData]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[FK_TemplateData_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[TemplateData]'))
	begin
	ALTER TABLE TemplateData drop CONSTRAINT  FK_TemplateData_NameObject
	end
end


IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[AmmeterTypeInfo]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[FK_AmmeterTypeInfo_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[AmmeterTypeInfo]'))
	begin
	ALTER TABLE AmmeterTypeInfo drop CONSTRAINT  FK_AmmeterTypeInfo_NameObject
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[NameObject]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[PK_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[NameObject]'))
	begin
		ALTER TABLE NameObject drop CONSTRAINT  PK_NameObject
		DROP TABLE dbo.NameObject
	end
end


	EXECUTE sp_rename N'dbo.Tmp_NameObject', N'NameObject', 'OBJECT' 
	
	
end;




/*
�޸ļ�¼:	ʱ��: 2011-8-11   �°汾�� 2.3.1.0    �ɰ汾��2.3.0.2
�޸���:	��ϼ
�޸�����: ɾ��nameobject��������޸�����  ��ɾ�� LinkageCondition��LinkageEvent��LinkageAct��
*/

IF not EXISTS ( SELECT name FROM syscolumns WHERE OBJECT_ID(N'NameObject') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'nServerNO' )
BEGIN	 
	ALTER TABLE NameObject ADD nServerNO INT NOT NULL DEFAULT 0
END
GO

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[TemplateData]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[FK_TemplateData_NameObject]') 
	    AND parent_object_id = OBJECT_ID(N'[dbo].[TemplateData]'))
	begin
	ALTER TABLE TemplateData drop CONSTRAINT  FK_TemplateData_NameObject
	end
end

go


IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].AmmeterTypeInfo') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM dbo.sysforeignkeys  WHERE constid = OBJECT_ID(N'[dbo].FK_AmmeterTypeInfo_NameObject') 
	    AND  fkeyid= OBJECT_ID(N'[dbo].AmmeterTypeInfo'))
	begin
	ALTER TABLE AmmeterTypeInfo drop CONSTRAINT  FK_AmmeterTypeInfo_NameObject
	end
end



if exists (select * 
from sysforeignkeys f join sysobjects o on f.constid=o.id 
where f.fkeyid=object_id('AmmeterTypeInfo') and name=N'FK_AmmeterTypeInfo_NameObject')
begin
ALTER TABLE AmmeterTypeInfo DROP CONSTRAINT [FK_AmmeterTypeInfo_NameObject]
end


IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].AmmeterTypeInfo') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sysforeignkeys  WHERE  constid= OBJECT_ID(N'[dbo].FK_AmmeterTypeInfo_NameObject') 
	    AND  fkeyid= OBJECT_ID(N'[dbo].AmmeterTypeInfo'))
	begin
	ALTER TABLE AmmeterTypeInfo drop CONSTRAINT  FK_AmmeterTypeInfo_NameObject
	end
end
go


IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'AlarmEvents') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sysforeignkeys WHERE constid = OBJECT_ID(N'FK_AlarmEvents_NameObject') 
	    AND fkeyid = OBJECT_ID(N'AlarmEvents'))
	begin
	ALTER TABLE AlarmEvents drop CONSTRAINT  FK_AlarmEvents_NameObject
	end
end
go



IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'AlarmCondition') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sysforeignkeys  WHERE constid = OBJECT_ID(N'FK_AlarmCondition_NameObject') 
	    AND fkeyid = OBJECT_ID(N'AlarmCondition'))
	begin
	ALTER TABLE AlarmCondition drop CONSTRAINT  FK_AlarmCondition_NameObject
	end
end
go


IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[AmmeterPrice]') AND type in (N'U'))
begin
	IF  EXISTS (SELECT * FROM sysforeignkeys  WHERE constid = OBJECT_ID(N'[dbo].[FK_AmmeterPrice_NameObject]')  
                AND fkeyid = OBJECT_ID(N'AmmeterPrice') )
	begin
	ALTER TABLE AmmeterPrice drop CONSTRAINT  FK_AmmeterPrice_NameObject
	end
end
go


IF EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[NameObject]') AND name = N'PK_NameObject')
begin
   ALTER TABLE [NameObject] DROP CONSTRAINT [PK_NameObject]
end
GO

IF NOT EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[NameObject]') AND name = N'PK_NameObject1')
begin
ALTER TABLE [NameObject] ADD  CONSTRAINT [PK_NameObject] PRIMARY KEY CLUSTERED 
(
	[nID] ASC,
	[nServerNO] ASC
)
end
GO

--�޸�nclassID  ��Ϊ��
alter table dbo.NameObject alter column nClassID int not null




--�޸�����
IF EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID(N'[NameObject]') AND name = N'PK_NameObject')
begin
   ALTER TABLE [NameObject] DROP CONSTRAINT [PK_NameObject]
end
GO

if not exists (select * from sysindexes where id=object_ID(N'NameObject') and name=N'PK_NameObject1')
begin
ALTER TABLE [NameObject] ADD  CONSTRAINT [PK_NameObject1] PRIMARY KEY CLUSTERED 
(
	[nID] ASC,
    [nClassID] ASC,
	[nServerNO] ASC
)
end
GO

--�޸���������Ϊ150
if  exists ( select name from syscolumns where OBJECT_ID(N'NameObject') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'strDescription' and  syscolumns.length = 100 )
          ALTER TABLE NameObject  ALTER COLUMN strDescription nvarchar (150)
GO
