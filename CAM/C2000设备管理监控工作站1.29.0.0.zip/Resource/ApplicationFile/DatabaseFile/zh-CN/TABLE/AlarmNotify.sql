IF not EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[AlarmNotify]') AND type in (N'U'))
begin
CREATE TABLE [dbo].[AlarmNotify](
	[nAlarmID] [bigint] NOT NULL,
	[nCardHolder] [int] NOT NULL,
	[nType] [int] NOT NULL,
	[dtTime] [datetime] NOT NULL,
	[strDesc] [nvarchar](50) NULL
) ON [PRIMARY]
end
GO