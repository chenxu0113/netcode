IF NOT EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'DBUpgradeRecord') AND OBJECTPROPERTY(ID, N'IsUserTable') = 1)
BEGIN
CREATE TABLE DBUpgradeRecord
(
	[nID]	[BIGINT] IDENTITY(1,1) NOT NULL,      --ID���
    [dtUpgradeTime] [DATETIME] NOT NULL,          --����ʱ��
    [strVersion] [nvarchar](50) NOT NULL,       --�������ݿ�汾
    
	CONSTRAINT DBUpgradeRecord_Primary_key
     	PRIMARY KEY NONCLUSTERED ( [nID] )   
)
END
GO