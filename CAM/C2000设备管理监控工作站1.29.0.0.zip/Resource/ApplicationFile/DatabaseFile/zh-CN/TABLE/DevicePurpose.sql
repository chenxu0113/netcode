IF NOT EXISTS (SELECT * FROM sysobjects WHERE ID = OBJECT_ID(N'DevicePurpose') AND OBJECTPROPERTY(ID, N'IsUserTable') = 1)
BEGIN
CREATE TABLE DevicePurpose
(
	[nID] [INT] NOT NULL,     --ID���
	[nPurpose] int NOT NULL,
	[strName] varchar(50) NOT NULL,
	[nServerNO] [INT] NOT NULL,                  --����ID
	
	CONSTRAINT PK_DevicePurpose
     	PRIMARY KEY CLUSTERED ( [nID],[nServerNO],[nPurpose] )   
)
END
GO

if exists(select * from sysobjects where name='DevicePurpose_Primary_key')
begin       
	alter table [DevicePurpose] drop constraint DevicePurpose_Primary_key
	
	ALTER TABLE [DevicePurpose] ADD  CONSTRAINT [PK_DevicePurpose] PRIMARY KEY CLUSTERED 
	(
		[nID],[nServerNO],[nPurpose]
	)

end
