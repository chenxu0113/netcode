IF not EXISTS (SELECT * FROM sysobjects WHERE Id = OBJECT_ID(N'[dbo].[ObjectID]') AND type in (N'U'))
begin


CREATE TABLE [dbo].[ObjectID](
	[nNextObjectID] [int],
	[nNextPointID] [int],
	[nNextAuthorizationRecordID] [int],
	[ObjectIDOverflow] [int],
	[PointIDOverflow] [int],
	[AuthorizationRecordIDOverflow] [int]
) ON [PRIMARY]
end

GO


if not exists ( select name from syscolumns where OBJECT_ID(N'ObjectID') = id 
            and OBJECTPROPERTY(ID, N'IsUserTable') = 1 and name = 'nMaxAlarmID' )
begin
	alter table ObjectID add nMaxAlarmID bigint NOT NULL DEFAULT 0
end
GO
