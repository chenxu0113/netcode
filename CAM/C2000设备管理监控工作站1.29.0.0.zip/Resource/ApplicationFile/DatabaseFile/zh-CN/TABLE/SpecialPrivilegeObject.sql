IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[SpecialPrivilegeObject]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SpecialPrivilegeObject](
	[nSpecialObjectClassID] [int] NOT NULL,	
	[nPrivilegeClassID] [int] NOT NULL,
	[nPrivilegeID] [int] NOT NULL,
) ON [PRIMARY]
END
GO