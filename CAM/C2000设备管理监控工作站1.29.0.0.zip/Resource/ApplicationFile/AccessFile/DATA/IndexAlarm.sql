
CREATE INDEX [Devive_IDEX] ON [Alarm] ([nDevice]) 
GO

CREATE INDEX [OccurTime_Index] ON [Alarm] ([dtOccurTime])
GO

CREATE INDEX [Controller_Index] ON [Alarm] ([nController])
GO

CREATE INDEX [Controller_OccurTime_Index] ON [Alarm] ([nController], dtOccurTime)
GO

CREATE INDEX [Controller_ClearTime_Index] ON [Alarm] ([nController], dtClearTime)
GO

CREATE INDEX [AlarmSource_IDEX] ON [Alarm] ([nAlarmSource]) 
GO
