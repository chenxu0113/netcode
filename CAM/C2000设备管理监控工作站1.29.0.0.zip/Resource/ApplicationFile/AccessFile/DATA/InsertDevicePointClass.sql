delete from InherentDevicePointClass
go

insert into InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(-2147483647,800,0,now(),now(),'����','����','')
go

insert into InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(-2147483646,800,0,now(),now(),'��ѹ','��ѹ','')
go

insert into InherentDevicePointClass(nId,nClassID,nServerNO,dtCreateTime,dtModifyTime,strName,strFullName,strDesc)
values(-2147483645,800,0,now(),now(),'����','����','')
 

 