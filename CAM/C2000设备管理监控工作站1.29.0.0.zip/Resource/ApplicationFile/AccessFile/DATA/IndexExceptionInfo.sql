
CREATE INDEX [ExceptionInfo_Device_Index] ON [ExceptionInfo] (nMacAddress)
