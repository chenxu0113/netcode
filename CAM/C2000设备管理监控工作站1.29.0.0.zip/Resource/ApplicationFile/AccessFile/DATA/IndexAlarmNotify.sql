
CREATE INDEX [AlarmNotify_AlarmID_Index] ON [AlarmNotify] (nAlarmID)
GO

CREATE INDEX [AlarmNotify_nCardHolder_Time_Index] ON [AlarmNotify] (nCardHolder, dtTime)
GO
