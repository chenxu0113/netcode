insert into SpecialPrivilegeObject values (853, 0, 0); 

GO

insert into SpecialPrivilegeObject values (853, 0, 1); 

GO

insert into SpecialPrivilegeObject values (853, 0, 2); 

GO

insert into SpecialPrivilegeObject values (853, 0, 3); 

GO

insert into SpecialPrivilegeObject values (853, 0, 20); 

GO

insert into SpecialPrivilegeObject values (853, 0, 21); 

GO

insert into SpecialPrivilegeObject values (853, 0, 6); 

GO

insert into SpecialPrivilegeObject values (853, 0, 7); 

GO

insert into SpecialPrivilegeObject values (853, 3, 0); 

GO

insert into SpecialPrivilegeObject values (853, 3, 1); 

GO

insert into SpecialPrivilegeObject values (853, 3, 2); 

GO

insert into SpecialPrivilegeObject values (853, 3, 3); 

GO

insert into SpecialPrivilegeObject values (853, 3, 20); 

GO

insert into SpecialPrivilegeObject values (853, 3, 21); 

GO

insert into SpecialPrivilegeObject values (853, 12, 0); 

GO

insert into SpecialPrivilegeObject values (853, 12, 1); 

GO

insert into SpecialPrivilegeObject values (853, 12, 2); 

GO

insert into SpecialPrivilegeObject values (853, 12, 3); 

GO

insert into SpecialPrivilegeObject values (853, 12, 5); 

GO

insert into SpecialPrivilegeObject values (853, 12, 6); 

GO

insert into SpecialPrivilegeObject values (853, 12, 7); 

GO

insert into SpecialPrivilegeObject values (853, 12, 30); 

GO

insert into SpecialPrivilegeObject values (853, 12, 31); 

GO

insert into SpecialPrivilegeObject values (853, 12, 32); 

GO

insert into SpecialPrivilegeObject values (853, 12, 27); 

GO

insert into SpecialPrivilegeObject values (853, 12, 22); 

GO

insert into SpecialPrivilegeObject values (853, 12, 23); 

GO

insert into SpecialPrivilegeObject values (853, 12, 24); 

GO

insert into SpecialPrivilegeObject values (853, 14, 0); 

GO

insert into SpecialPrivilegeObject values (853, 14, 1); 

GO

insert into SpecialPrivilegeObject values (853, 14, 2); 

GO

insert into SpecialPrivilegeObject values (853, 14, 3); 

GO

insert into SpecialPrivilegeObject values (853, 16, 0); 

GO

insert into SpecialPrivilegeObject values (853, 16, 1); 

GO

insert into SpecialPrivilegeObject values (853, 16, 2); 

GO

insert into SpecialPrivilegeObject values (853, 16, 3); 

GO

insert into SpecialPrivilegeObject values (853, 16, 6); 

GO

insert into SpecialPrivilegeObject values (853, 16, 7); 

GO

insert into SpecialPrivilegeObject values (853, 38, 0); 

GO

insert into SpecialPrivilegeObject values (853, 38, 1); 

GO

insert into SpecialPrivilegeObject values (853, 38, 2); 

GO

insert into SpecialPrivilegeObject values (853, 38, 3); 

GO

insert into SpecialPrivilegeObject values (853, 58, 0); 

GO

insert into SpecialPrivilegeObject values (853, 58, 1); 

GO

insert into SpecialPrivilegeObject values (853, 58, 2); 

GO

insert into SpecialPrivilegeObject values (853, 58, 3); 

GO

insert into SpecialPrivilegeObject values (853, 58, 33); 

GO

insert into SpecialPrivilegeObject values (853, 58, 34); 

GO

insert into SpecialPrivilegeObject values (853, 58, 35); 

GO

insert into SpecialPrivilegeObject values (853, 59, 0); 

GO

insert into SpecialPrivilegeObject values (853, 59, 1); 

GO

insert into SpecialPrivilegeObject values (853, 59, 2); 

GO

insert into SpecialPrivilegeObject values (853, 59, 3); 

GO

insert into SpecialPrivilegeObject values (853, 59, 20); 

GO

insert into SpecialPrivilegeObject values (853, 59, 21); 

GO

insert into SpecialPrivilegeObject values (853, 59, 33); 

GO

insert into SpecialPrivilegeObject values (853, 60, 0); 

GO

insert into SpecialPrivilegeObject values (853, 60, 4); 

GO

insert into SpecialPrivilegeObject values (853, 62, 0); 

GO

insert into SpecialPrivilegeObject values (853, 62, 1); 

GO

insert into SpecialPrivilegeObject values (853, 62, 2); 

GO

insert into SpecialPrivilegeObject values (853, 62, 3); 

GO

insert into SpecialPrivilegeObject values (853, 62, 20); 

GO

insert into SpecialPrivilegeObject values (853, 62, 33); 

GO

insert into SpecialPrivilegeObject values (853, 62, 21); 

GO

insert into SpecialPrivilegeObject values (853, 63, 0); 

GO

insert into SpecialPrivilegeObject values (853, 63, 1); 

GO

insert into SpecialPrivilegeObject values (853, 63, 2); 

GO

insert into SpecialPrivilegeObject values (853, 63, 3); 

GO

insert into SpecialPrivilegeObject values (853, 63, 20); 

GO

insert into SpecialPrivilegeObject values (853, 63, 21); 

GO

insert into SpecialPrivilegeObject values (853, 63, 33); 

GO

insert into SpecialPrivilegeObject values (853, 73, 0); 

GO

insert into SpecialPrivilegeObject values (853, 73, 1); 

GO

insert into SpecialPrivilegeObject values (853, 73, 2); 

GO

insert into SpecialPrivilegeObject values (853, 73, 3); 

GO

insert into SpecialPrivilegeObject values (853, 73, 5); 

GO

insert into SpecialPrivilegeObject values (853, 73, 19); 

GO

insert into SpecialPrivilegeObject values (853, 73, 6); 

GO

insert into SpecialPrivilegeObject values (853, 73, 7); 

GO

insert into SpecialPrivilegeObject values (853, 73, 8); 

GO

insert into SpecialPrivilegeObject values (853, 73, 9); 

GO

insert into SpecialPrivilegeObject values (853, 73, 10); 

GO

insert into SpecialPrivilegeObject values (853, 73, 11); 

GO

insert into SpecialPrivilegeObject values (853, 73, 12); 

GO

insert into SpecialPrivilegeObject values (853, 73, 13); 

GO

insert into SpecialPrivilegeObject values (853, 73, 30); 

GO

insert into SpecialPrivilegeObject values (853, 73, 31); 

GO

insert into SpecialPrivilegeObject values (853, 73, 32); 

GO

insert into SpecialPrivilegeObject values (853, 73, 27); 

GO

insert into SpecialPrivilegeObject values (853, 73, 22); 

GO

insert into SpecialPrivilegeObject values (853, 73, 23); 

GO

insert into SpecialPrivilegeObject values (853, 73, 24); 

GO

insert into SpecialPrivilegeObject values (853, 92, 1); 

GO

insert into SpecialPrivilegeObject values (853, 92, 2); 

GO

insert into SpecialPrivilegeObject values (853, 92, 3); 

GO

insert into SpecialPrivilegeObject values (853, 93, 0); 

GO

insert into SpecialPrivilegeObject values (853, 93, 1); 

GO

insert into SpecialPrivilegeObject values (853, 93, 2); 

GO

insert into SpecialPrivilegeObject values (853, 93, 3); 

GO

insert into SpecialPrivilegeObject values (853, 93, 20); 

GO

insert into SpecialPrivilegeObject values (853, 93, 21); 

GO

insert into SpecialPrivilegeObject values (853, 94, 0); 

GO

insert into SpecialPrivilegeObject values (853, 94, 1); 

GO

insert into SpecialPrivilegeObject values (853, 94, 2); 

GO

insert into SpecialPrivilegeObject values (853, 94, 3); 

GO

insert into SpecialPrivilegeObject values (853, 95, 0); 

GO

insert into SpecialPrivilegeObject values (853, 95, 1); 

GO

insert into SpecialPrivilegeObject values (853, 95, 2); 

GO

insert into SpecialPrivilegeObject values (853, 95, 3); 

GO

insert into SpecialPrivilegeObject values (853, 96, 0); 

GO

insert into SpecialPrivilegeObject values (853, 96, 4); 

GO

insert into SpecialPrivilegeObject values (853, 97, 0); 

GO

insert into SpecialPrivilegeObject values (853, 97, 1); 

GO

insert into SpecialPrivilegeObject values (853, 97, 2); 

GO

insert into SpecialPrivilegeObject values (853, 97, 3); 

GO

insert into SpecialPrivilegeObject values (853, 113, 0); 

GO

insert into SpecialPrivilegeObject values (853, 113, 1); 

GO

insert into SpecialPrivilegeObject values (853, 113, 2); 

GO

insert into SpecialPrivilegeObject values (853, 113, 3); 

GO

insert into SpecialPrivilegeObject values (853, 113, 5); 

GO

insert into SpecialPrivilegeObject values (853, 113, 20); 

GO

insert into SpecialPrivilegeObject values (853, 113, 21); 

GO

insert into SpecialPrivilegeObject values (853, 161, 0); 

GO

insert into SpecialPrivilegeObject values (853, 161, 1); 

GO

insert into SpecialPrivilegeObject values (853, 161, 2); 

GO

insert into SpecialPrivilegeObject values (853, 161, 3); 

GO

insert into SpecialPrivilegeObject values (853, 162, 0); 

GO

insert into SpecialPrivilegeObject values (853, 162, 1); 

GO

insert into SpecialPrivilegeObject values (853, 162, 2); 

GO

insert into SpecialPrivilegeObject values (853, 162, 3); 

GO

insert into SpecialPrivilegeObject values (853, 163, 0); 

GO

insert into SpecialPrivilegeObject values (853, 163, 1); 

GO

insert into SpecialPrivilegeObject values (853, 163, 2); 

GO

insert into SpecialPrivilegeObject values (853, 163, 3); 

GO

insert into SpecialPrivilegeObject values (853, 187, 0); 

GO

insert into SpecialPrivilegeObject values (853, 187, 1); 

GO

insert into SpecialPrivilegeObject values (853, 187, 2); 

GO

insert into SpecialPrivilegeObject values (853, 187, 3); 

GO

insert into SpecialPrivilegeObject values (853, 223, 0); 

GO

insert into SpecialPrivilegeObject values (853, 223, 1); 

GO

insert into SpecialPrivilegeObject values (853, 223, 2); 

GO

insert into SpecialPrivilegeObject values (853, 223, 3); 

GO

insert into SpecialPrivilegeObject values (853, 350, 0); 

GO

insert into SpecialPrivilegeObject values (853, 350, 1); 

GO

insert into SpecialPrivilegeObject values (853, 350, 2); 

GO

insert into SpecialPrivilegeObject values (853, 350, 3); 

GO

insert into SpecialPrivilegeObject values (853, 350, 20); 

GO

insert into SpecialPrivilegeObject values (853, 350, 21); 

GO

insert into SpecialPrivilegeObject values (853, 351, 0); 

GO

insert into SpecialPrivilegeObject values (853, 351, 1); 

GO

insert into SpecialPrivilegeObject values (853, 351, 2); 

GO

insert into SpecialPrivilegeObject values (853, 351, 3); 

GO

insert into SpecialPrivilegeObject values (853, 351, 20); 

GO

insert into SpecialPrivilegeObject values (853, 351, 21); 

GO

insert into SpecialPrivilegeObject values (853, 352, 0); 

GO

insert into SpecialPrivilegeObject values (853, 352, 1); 

GO

insert into SpecialPrivilegeObject values (853, 352, 2); 

GO

insert into SpecialPrivilegeObject values (853, 352, 3); 

GO

insert into SpecialPrivilegeObject values (853, 352, 20); 

GO

insert into SpecialPrivilegeObject values (853, 352, 21); 

GO

insert into SpecialPrivilegeObject values (853, 353, 0); 

GO

insert into SpecialPrivilegeObject values (853, 353, 1); 

GO

insert into SpecialPrivilegeObject values (853, 353, 2); 

GO

insert into SpecialPrivilegeObject values (853, 353, 3); 

GO

insert into SpecialPrivilegeObject values (853, 353, 20); 

GO

insert into SpecialPrivilegeObject values (853, 353, 21); 

GO

insert into SpecialPrivilegeObject values (853, 354, 0); 

GO

insert into SpecialPrivilegeObject values (853, 354, 1); 

GO

insert into SpecialPrivilegeObject values (853, 354, 2); 

GO

insert into SpecialPrivilegeObject values (853, 354, 3); 

GO

insert into SpecialPrivilegeObject values (853, 354, 20); 

GO

insert into SpecialPrivilegeObject values (853, 354, 21); 

GO

insert into SpecialPrivilegeObject values (853, 355, 0); 

GO

insert into SpecialPrivilegeObject values (853, 355, 1); 

GO

insert into SpecialPrivilegeObject values (853, 355, 2); 

GO

insert into SpecialPrivilegeObject values (853, 355, 3); 

GO

insert into SpecialPrivilegeObject values (853, 355, 20); 

GO

insert into SpecialPrivilegeObject values (853, 355, 21); 

GO

insert into SpecialPrivilegeObject values (853, 400, 0); 

GO

insert into SpecialPrivilegeObject values (853, 400, 1); 

GO

insert into SpecialPrivilegeObject values (853, 400, 2); 

GO

insert into SpecialPrivilegeObject values (853, 400, 3); 

GO

insert into SpecialPrivilegeObject values (853, 400, 99); 

GO

insert into SpecialPrivilegeObject values (853, 401, 0); 

GO

insert into SpecialPrivilegeObject values (853, 401, 1); 

GO

insert into SpecialPrivilegeObject values (853, 401, 2); 

GO

insert into SpecialPrivilegeObject values (853, 401, 3); 

GO

insert into SpecialPrivilegeObject values (853, 401, 20); 

GO

insert into SpecialPrivilegeObject values (853, 401, 21); 

GO

insert into SpecialPrivilegeObject values (853, 402, 0); 

GO

insert into SpecialPrivilegeObject values (853, 402, 1); 

GO

insert into SpecialPrivilegeObject values (853, 402, 2); 

GO

insert into SpecialPrivilegeObject values (853, 402, 3); 

GO

insert into SpecialPrivilegeObject values (853, 403, 0); 

GO

insert into SpecialPrivilegeObject values (853, 403, 1); 

GO

insert into SpecialPrivilegeObject values (853, 403, 2); 

GO

insert into SpecialPrivilegeObject values (853, 403, 3); 

GO

insert into SpecialPrivilegeObject values (853, 403, 99); 

GO

insert into SpecialPrivilegeObject values (853, 404, 0); 

GO

insert into SpecialPrivilegeObject values (853, 404, 1); 

GO

insert into SpecialPrivilegeObject values (853, 404, 2); 

GO

insert into SpecialPrivilegeObject values (853, 404, 3); 

GO

insert into SpecialPrivilegeObject values (853, 404, 99); 

GO

insert into SpecialPrivilegeObject values (853, 502, 0); 

GO

insert into SpecialPrivilegeObject values (853, 502, 1); 

GO

insert into SpecialPrivilegeObject values (853, 502, 2); 

GO

insert into SpecialPrivilegeObject values (853, 502, 3); 

GO

insert into SpecialPrivilegeObject values (853, 601, 0); 

GO

insert into SpecialPrivilegeObject values (853, 601, 1); 

GO

insert into SpecialPrivilegeObject values (853, 601, 2); 

GO

insert into SpecialPrivilegeObject values (853, 601, 3); 

GO

insert into SpecialPrivilegeObject values (853, 601, 20); 

GO

insert into SpecialPrivilegeObject values (853, 601, 21); 

GO

insert into SpecialPrivilegeObject values (853, 602, 0); 

GO

insert into SpecialPrivilegeObject values (853, 700, 0); 

GO

insert into SpecialPrivilegeObject values (853, 700, 1); 

GO

insert into SpecialPrivilegeObject values (853, 700, 2); 

GO

insert into SpecialPrivilegeObject values (853, 700, 3); 

GO

insert into SpecialPrivilegeObject values (853, 701, 0); 

GO

insert into SpecialPrivilegeObject values (853, 701, 1); 

GO

insert into SpecialPrivilegeObject values (853, 701, 2); 

GO

insert into SpecialPrivilegeObject values (853, 701, 3); 

GO

insert into SpecialPrivilegeObject values (853, 750, 0); 

GO

insert into SpecialPrivilegeObject values (853, 750, 1); 

GO

insert into SpecialPrivilegeObject values (853, 750, 2); 

GO

insert into SpecialPrivilegeObject values (853, 750, 3); 

GO

insert into SpecialPrivilegeObject values (853, 800, 0); 

GO

insert into SpecialPrivilegeObject values (853, 800, 1); 

GO

insert into SpecialPrivilegeObject values (853, 800, 2); 

GO

insert into SpecialPrivilegeObject values (853, 800, 3); 

GO

insert into SpecialPrivilegeObject values (853, 900, 0); 

GO

insert into SpecialPrivilegeObject values (853, 900, 3); 

GO

insert into SpecialPrivilegeObject values (853, 900, 5); 

GO

insert into SpecialPrivilegeObject values (853, 900, 14); 

GO

insert into SpecialPrivilegeObject values (853, 900, 15); 

GO

insert into SpecialPrivilegeObject values (853, 900, 16); 

GO

insert into SpecialPrivilegeObject values (853, 900, 17); 

GO

insert into SpecialPrivilegeObject values (853, 900, 6); 

GO

insert into SpecialPrivilegeObject values (853, 900, 7); 

GO

insert into SpecialPrivilegeObject values (853, 900, 27); 

GO

insert into SpecialPrivilegeObject values (853, 900, 25); 

GO

insert into SpecialPrivilegeObject values (853, 900, 26); 

GO

insert into SpecialPrivilegeObject values (853, 1000000, 0); 

GO

insert into SpecialPrivilegeObject values (853, 1000000, 4); 

GO

insert into SpecialPrivilegeObject values (853, 1000001, 0); 

GO

insert into SpecialPrivilegeObject values (853, 1000001, 4); 

GO

insert into SpecialPrivilegeObject values (853, 1000002, 4); 

GO

insert into SpecialPrivilegeObject values (853, 1000003, 4); 

GO

insert into SpecialPrivilegeObject values (853, 1000004, 18); 

GO

insert into SpecialPrivilegeObject values (853, 1000005, 18); 

GO

insert into SpecialPrivilegeObject values (853, 1000006, 18); 

GO

insert into SpecialPrivilegeObject values (853, 1000008, 0); 

GO

insert into SpecialPrivilegeObject values (853, 1000008, 1); 

GO

insert into SpecialPrivilegeObject values (853, 1000008, 2); 

GO

insert into SpecialPrivilegeObject values (853, 1000008, 3); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 0); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 1); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 2); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 3); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 20); 

GO

insert into SpecialPrivilegeObject values (853, 1000009, 21); 

GO


insert into SpecialPrivilegeObject values (854, 0, 0); 

GO

insert into SpecialPrivilegeObject values (854, 0, 1); 

GO

insert into SpecialPrivilegeObject values (854, 0, 2); 

GO

insert into SpecialPrivilegeObject values (854, 0, 3); 

GO

insert into SpecialPrivilegeObject values (854, 3, 0); 

GO

insert into SpecialPrivilegeObject values (854, 3, 1); 

GO

insert into SpecialPrivilegeObject values (854, 3, 2); 

GO

insert into SpecialPrivilegeObject values (854, 3, 3); 

GO

insert into SpecialPrivilegeObject values (854, 3, 20); 

GO

insert into SpecialPrivilegeObject values (854, 3, 21); 

GO

insert into SpecialPrivilegeObject values (854, 12, 0); 

GO

insert into SpecialPrivilegeObject values (854, 12, 1); 

GO

insert into SpecialPrivilegeObject values (854, 12, 2); 

GO

insert into SpecialPrivilegeObject values (854, 12, 3); 

GO

insert into SpecialPrivilegeObject values (854, 12, 5); 

GO

insert into SpecialPrivilegeObject values (854, 12, 6); 

GO

insert into SpecialPrivilegeObject values (854, 12, 7); 

GO

insert into SpecialPrivilegeObject values (854, 12, 30); 

GO

insert into SpecialPrivilegeObject values (854, 12, 31); 

GO

insert into SpecialPrivilegeObject values (854, 12, 32); 

GO

insert into SpecialPrivilegeObject values (854, 12, 27); 

GO

insert into SpecialPrivilegeObject values (854, 12, 22); 

GO

insert into SpecialPrivilegeObject values (854, 12, 23); 

GO

insert into SpecialPrivilegeObject values (854, 12, 24); 

GO

insert into SpecialPrivilegeObject values (854, 14, 0); 

GO

insert into SpecialPrivilegeObject values (854, 14, 1); 

GO

insert into SpecialPrivilegeObject values (854, 14, 2); 

GO

insert into SpecialPrivilegeObject values (854, 14, 3); 

GO

insert into SpecialPrivilegeObject values (854, 62, 0); 

GO

insert into SpecialPrivilegeObject values (854, 62, 1); 

GO

insert into SpecialPrivilegeObject values (854, 62, 2); 

GO

insert into SpecialPrivilegeObject values (854, 62, 3); 

GO

insert into SpecialPrivilegeObject values (854, 63, 0); 

GO

insert into SpecialPrivilegeObject values (854, 63, 1); 

GO

insert into SpecialPrivilegeObject values (854, 63, 2); 

GO

insert into SpecialPrivilegeObject values (854, 63, 3); 

GO

insert into SpecialPrivilegeObject values (854, 63, 20); 

GO

insert into SpecialPrivilegeObject values (854, 63, 21); 

GO

insert into SpecialPrivilegeObject values (854, 73, 0); 

GO

insert into SpecialPrivilegeObject values (854, 73, 1); 

GO

insert into SpecialPrivilegeObject values (854, 73, 2); 

GO

insert into SpecialPrivilegeObject values (854, 73, 3); 

GO

insert into SpecialPrivilegeObject values (854, 73, 5); 

GO

insert into SpecialPrivilegeObject values (854, 73, 19); 

GO

insert into SpecialPrivilegeObject values (854, 73, 6); 

GO

insert into SpecialPrivilegeObject values (854, 73, 7); 

GO

insert into SpecialPrivilegeObject values (854, 73, 8); 

GO

insert into SpecialPrivilegeObject values (854, 73, 9); 

GO

insert into SpecialPrivilegeObject values (854, 73, 10); 

GO

insert into SpecialPrivilegeObject values (854, 73, 11); 

GO

insert into SpecialPrivilegeObject values (854, 73, 12); 

GO

insert into SpecialPrivilegeObject values (854, 73, 13); 

GO

insert into SpecialPrivilegeObject values (854, 73, 30); 

GO

insert into SpecialPrivilegeObject values (854, 73, 31); 

GO

insert into SpecialPrivilegeObject values (854, 73, 32); 

GO

insert into SpecialPrivilegeObject values (854, 73, 27); 

GO

insert into SpecialPrivilegeObject values (854, 73, 22); 

GO

insert into SpecialPrivilegeObject values (854, 73, 23); 

GO

insert into SpecialPrivilegeObject values (854, 73, 24); 

GO

insert into SpecialPrivilegeObject values (854, 223, 0); 

GO

insert into SpecialPrivilegeObject values (854, 223, 1); 

GO

insert into SpecialPrivilegeObject values (854, 223, 2); 

GO

insert into SpecialPrivilegeObject values (854, 223, 3); 

GO

insert into SpecialPrivilegeObject values (854, 350, 0); 

GO

insert into SpecialPrivilegeObject values (854, 350, 1); 

GO

insert into SpecialPrivilegeObject values (854, 350, 2); 

GO

insert into SpecialPrivilegeObject values (854, 350, 3); 

GO

insert into SpecialPrivilegeObject values (854, 351, 0); 

GO

insert into SpecialPrivilegeObject values (854, 351, 1); 

GO

insert into SpecialPrivilegeObject values (854, 351, 2); 

GO

insert into SpecialPrivilegeObject values (854, 351, 3); 

GO

insert into SpecialPrivilegeObject values (854, 352, 0); 

GO

insert into SpecialPrivilegeObject values (854, 352, 1); 

GO

insert into SpecialPrivilegeObject values (854, 352, 2); 

GO

insert into SpecialPrivilegeObject values (854, 352, 3); 

GO

insert into SpecialPrivilegeObject values (854, 353, 0); 

GO

insert into SpecialPrivilegeObject values (854, 353, 1); 

GO

insert into SpecialPrivilegeObject values (854, 353, 2); 

GO

insert into SpecialPrivilegeObject values (854, 353, 3); 

GO

insert into SpecialPrivilegeObject values (854, 354, 0); 

GO

insert into SpecialPrivilegeObject values (854, 354, 1); 

GO

insert into SpecialPrivilegeObject values (854, 354, 2); 

GO

insert into SpecialPrivilegeObject values (854, 354, 3); 

GO

insert into SpecialPrivilegeObject values (854, 355, 0); 

GO

insert into SpecialPrivilegeObject values (854, 355, 1); 

GO

insert into SpecialPrivilegeObject values (854, 355, 2); 

GO

insert into SpecialPrivilegeObject values (854, 355, 3); 

GO

insert into SpecialPrivilegeObject values (854, 400, 0); 

GO

insert into SpecialPrivilegeObject values (854, 400, 1); 

GO

insert into SpecialPrivilegeObject values (854, 400, 2); 

GO

insert into SpecialPrivilegeObject values (854, 400, 3); 

GO

insert into SpecialPrivilegeObject values (854, 400, 99); 

GO

insert into SpecialPrivilegeObject values (854, 401, 0); 

GO

insert into SpecialPrivilegeObject values (854, 401, 1); 

GO

insert into SpecialPrivilegeObject values (854, 401, 2); 

GO

insert into SpecialPrivilegeObject values (854, 401, 3); 

GO

insert into SpecialPrivilegeObject values (854, 900, 0); 

GO

insert into SpecialPrivilegeObject values (854, 900, 3); 

GO

insert into SpecialPrivilegeObject values (854, 900, 14); 

GO

insert into SpecialPrivilegeObject values (854, 900, 15); 

GO

insert into SpecialPrivilegeObject values (854, 900, 16); 

GO

insert into SpecialPrivilegeObject values (854, 900, 17); 

GO

insert into SpecialPrivilegeObject values (854, 900, 6); 

GO

insert into SpecialPrivilegeObject values (854, 900, 7); 

GO

insert into SpecialPrivilegeObject values (854, 900, 27); 

GO

insert into SpecialPrivilegeObject values (854, 900, 25); 

GO

insert into SpecialPrivilegeObject values (854, 900, 26); 

GO

insert into SpecialPrivilegeObject values (857, 0, 0); 

GO

insert into SpecialPrivilegeObject values (857, 0, 1); 

GO

insert into SpecialPrivilegeObject values (857, 0, 2); 

GO

insert into SpecialPrivilegeObject values (857, 0, 3); 

GO

insert into SpecialPrivilegeObject values (857, 3, 0); 

GO

insert into SpecialPrivilegeObject values (857, 3, 1); 

GO

insert into SpecialPrivilegeObject values (857, 3, 2); 

GO

insert into SpecialPrivilegeObject values (857, 3, 3); 

GO

insert into SpecialPrivilegeObject values (857, 3, 20); 

GO

insert into SpecialPrivilegeObject values (857, 3, 21); 

GO

insert into SpecialPrivilegeObject values (857, 58, 0); 

GO

insert into SpecialPrivilegeObject values (857, 58, 1); 

GO

insert into SpecialPrivilegeObject values (857, 58, 2); 

GO

insert into SpecialPrivilegeObject values (857, 58, 3); 

GO

insert into SpecialPrivilegeObject values (857, 59, 0); 

GO

insert into SpecialPrivilegeObject values (857, 59, 1); 

GO

insert into SpecialPrivilegeObject values (857, 59, 2); 

GO

insert into SpecialPrivilegeObject values (857, 59, 3); 

GO

insert into SpecialPrivilegeObject values (857, 59, 20); 

GO

insert into SpecialPrivilegeObject values (857, 59, 21); 

GO

insert into SpecialPrivilegeObject values (857, 92, 1); 

GO

insert into SpecialPrivilegeObject values (857, 92, 2); 

GO

insert into SpecialPrivilegeObject values (857, 92, 3); 

GO

insert into SpecialPrivilegeObject values (857, 93, 0); 

GO

insert into SpecialPrivilegeObject values (857, 93, 1); 

GO

insert into SpecialPrivilegeObject values (857, 93, 2); 

GO

insert into SpecialPrivilegeObject values (857, 93, 3); 

GO

insert into SpecialPrivilegeObject values (857, 93, 20); 

GO

insert into SpecialPrivilegeObject values (857, 93, 21); 

GO

insert into SpecialPrivilegeObject values (857, 94, 0); 

GO

insert into SpecialPrivilegeObject values (857, 94, 1); 

GO

insert into SpecialPrivilegeObject values (857, 94, 2); 

GO

insert into SpecialPrivilegeObject values (857, 94, 3); 

GO

insert into SpecialPrivilegeObject values (857, 95, 0); 

GO

insert into SpecialPrivilegeObject values (857, 95, 1); 

GO

insert into SpecialPrivilegeObject values (857, 95, 2); 

GO

insert into SpecialPrivilegeObject values (857, 95, 3); 

GO

insert into SpecialPrivilegeObject values (857, 96, 0); 

GO

insert into SpecialPrivilegeObject values (857, 96, 4); 

GO

insert into SpecialPrivilegeObject values (857, 97, 0); 

GO

insert into SpecialPrivilegeObject values (857, 97, 1); 

GO

insert into SpecialPrivilegeObject values (857, 97, 2); 

GO

insert into SpecialPrivilegeObject values (857, 97, 3); 

GO

insert into SpecialPrivilegeObject values (857, 1000005, 18); 

GO

insert into SpecialPrivilegeObject values (855, 0, 0); 

GO

insert into SpecialPrivilegeObject values (855, 0, 1); 

GO

insert into SpecialPrivilegeObject values (855, 0, 2); 

GO

insert into SpecialPrivilegeObject values (855, 0, 3); 

GO

insert into SpecialPrivilegeObject values (855, 3, 0); 

GO

insert into SpecialPrivilegeObject values (855, 3, 1); 

GO

insert into SpecialPrivilegeObject values (855, 3, 2); 

GO

insert into SpecialPrivilegeObject values (855, 3, 3); 

GO

insert into SpecialPrivilegeObject values (855, 3, 20); 

GO

insert into SpecialPrivilegeObject values (855, 3, 21); 

GO

insert into SpecialPrivilegeObject values (855, 38, 0); 

GO

insert into SpecialPrivilegeObject values (855, 38, 1); 

GO

insert into SpecialPrivilegeObject values (855, 38, 2); 

GO

insert into SpecialPrivilegeObject values (855, 38, 3); 

GO

insert into SpecialPrivilegeObject values (855, 58, 0); 

GO

insert into SpecialPrivilegeObject values (855, 58, 1); 

GO

insert into SpecialPrivilegeObject values (855, 58, 2); 

GO

insert into SpecialPrivilegeObject values (855, 58, 3); 

GO

insert into SpecialPrivilegeObject values (855, 59, 0); 

GO

insert into SpecialPrivilegeObject values (855, 59, 1); 

GO

insert into SpecialPrivilegeObject values (855, 59, 2); 

GO

insert into SpecialPrivilegeObject values (855, 59, 3); 

GO

insert into SpecialPrivilegeObject values (855, 59, 20); 

GO

insert into SpecialPrivilegeObject values (855, 59, 21); 

GO

insert into SpecialPrivilegeObject values (855, 62, 0); 

GO

insert into SpecialPrivilegeObject values (855, 62, 1); 

GO

insert into SpecialPrivilegeObject values (855, 62, 2); 

GO

insert into SpecialPrivilegeObject values (855, 62, 3); 

GO

insert into SpecialPrivilegeObject values (855, 502, 0); 

GO

insert into SpecialPrivilegeObject values (855, 502, 1); 

GO

insert into SpecialPrivilegeObject values (855, 502, 2); 

GO

insert into SpecialPrivilegeObject values (855, 502, 3); 

GO

insert into SpecialPrivilegeObject values (855, 502, 200); 

GO

insert into SpecialPrivilegeObject values (855, 502, 201); 

GO

insert into SpecialPrivilegeObject values (855, 502, 202); 

GO

insert into SpecialPrivilegeObject values (855, 601, 0); 

GO

insert into SpecialPrivilegeObject values (855, 601, 1); 

GO

insert into SpecialPrivilegeObject values (855, 601, 2); 

GO

insert into SpecialPrivilegeObject values (855, 601, 3); 

GO

insert into SpecialPrivilegeObject values (855, 602, 0); 

GO

insert into SpecialPrivilegeObject values (855, 1902, 0); 

GO

insert into SpecialPrivilegeObject values (855, 1902, 1); 

GO

insert into SpecialPrivilegeObject values (855, 1902, 2); 

GO

insert into SpecialPrivilegeObject values (855, 1902, 3); 

GO

insert into SpecialPrivilegeObject values (855, 1903, 0); 

GO

insert into SpecialPrivilegeObject values (855, 1903, 1); 

GO

insert into SpecialPrivilegeObject values (855, 1903, 2); 

GO

insert into SpecialPrivilegeObject values (855, 1903, 3); 

GO

insert into SpecialPrivilegeObject values (858, 0, 0); 

GO

insert into SpecialPrivilegeObject values (858, 0, 1); 

GO

insert into SpecialPrivilegeObject values (858, 0, 2); 

GO

insert into SpecialPrivilegeObject values (858, 0, 3); 

GO

insert into SpecialPrivilegeObject values (858, 3, 0); 

GO

insert into SpecialPrivilegeObject values (858, 3, 1); 

GO

insert into SpecialPrivilegeObject values (858, 3, 2); 

GO

insert into SpecialPrivilegeObject values (858, 3, 3); 

GO

insert into SpecialPrivilegeObject values (858, 3, 20); 

GO

insert into SpecialPrivilegeObject values (858, 3, 21); 

GO

insert into SpecialPrivilegeObject values (858, 58, 0); 

GO

insert into SpecialPrivilegeObject values (858, 58, 1); 

GO

insert into SpecialPrivilegeObject values (858, 58, 2); 

GO

insert into SpecialPrivilegeObject values (858, 58, 3); 

GO

insert into SpecialPrivilegeObject values (858, 59, 0); 

GO

insert into SpecialPrivilegeObject values (858, 59, 1); 

GO

insert into SpecialPrivilegeObject values (858, 59, 2); 

GO

insert into SpecialPrivilegeObject values (858, 59, 3); 

GO

insert into SpecialPrivilegeObject values (858, 59, 20); 

GO

insert into SpecialPrivilegeObject values (858, 59, 21); 

GO

insert into SpecialPrivilegeObject values (858, 62, 0); 

GO

insert into SpecialPrivilegeObject values (858, 62, 1); 

GO

insert into SpecialPrivilegeObject values (858, 62, 2); 

GO

insert into SpecialPrivilegeObject values (858, 62, 3); 

GO

insert into SpecialPrivilegeObject values (858, 63, 0); 

GO

insert into SpecialPrivilegeObject values (858, 63, 1); 

GO

insert into SpecialPrivilegeObject values (858, 63, 2); 

GO

insert into SpecialPrivilegeObject values (858, 63, 3); 

GO

insert into SpecialPrivilegeObject values (858, 63, 20); 

GO

insert into SpecialPrivilegeObject values (858, 63, 21); 

GO

insert into SpecialPrivilegeObject values (858, 1000000, 0); 

GO

insert into SpecialPrivilegeObject values (858, 1000000, 4); 

GO

insert into SpecialPrivilegeObject values (858, 1000001, 0); 

GO

insert into SpecialPrivilegeObject values (858, 1000001, 4); 

GO

insert into SpecialPrivilegeObject values (858, 1000002, 4); 

GO

insert into SpecialPrivilegeObject values (858, 1000003, 4); 

GO

insert into SpecialPrivilegeObject values (858, 1000004, 18); 

GO

insert into SpecialPrivilegeObject values (858, 1000005, 18); 

GO



