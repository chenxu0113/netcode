
CREATE INDEX [PointValue_Index] ON [PointValue] 
(
	[nDeviceID] ASC,
	[date] ASC
)
