
ALTER TABLE [Alarm] ALTER COLUMN [nServerNO] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nAlarmConfirmType] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nDataVersion] int not null default 1
GO

ALTER TABLE [Alarm] ALTER COLUMN [bConfirm] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [bClear] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nAreaID] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nAlarmTemplate] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nActuator] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nAlarmSourceClass] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nAlarmSource] int not null default 0
GO

ALTER TABLE [Alarm] ALTER COLUMN [nOrgDataVersion] int not null default 0
GO
